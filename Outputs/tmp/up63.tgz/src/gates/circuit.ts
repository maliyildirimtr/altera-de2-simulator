/**
 * Gate-level circuit model for the drawing editor: evaluation (with
 * flip-flop state and clock edges), unit-delay timing simulation (for
 * glitches), truth tables and Verilog generation. Pure functions, no React.
 *
 * Every part has numbered input pins and numbered output pins. A signal is
 * one output pin of one node; its key is the node id for pin 0 and
 * `id#pin` for the others (see `sig`).
 */

export type GateType =
  // sources and sinks
  | 'IN' | 'OUT' | 'LED' | 'BTN' | 'CLK' | 'CONST0' | 'CONST1' | 'SEG7' | 'TUNNEL'
  // a saved circuit used as a block
  | 'BLOCK'
  // gates
  | 'AND' | 'OR' | 'NOT' | 'NAND' | 'NOR' | 'XOR' | 'XNOR' | 'BUF'
  // plexers
  | 'MUX2' | 'MUX4' | 'DEMUX2' | 'DEMUX4' | 'DEC2' | 'DEC3' | 'BITSEL' | 'PENC4'
  // arithmetic
  | 'HA' | 'FA' | 'ADD' | 'SUB' | 'MUL' | 'DIV' | 'SHIFT' | 'CMP' | 'NEG' | 'SEXT' | 'BITCNT'
  // flip-flops (rising edge)
  | 'DFF' | 'TFF' | 'JKFF' | 'SRFF'
  // buses: constant, splitter, merger
  | 'CONST' | 'SPLIT' | 'MERGE'
  // memory: register, RAM, ROM
  | 'REG' | 'RAM' | 'ROM';

export interface GateNode {
  id: string;
  type: GateType;
  x: number;
  y: number;
  /** Signal name for IN/OUT/BTN/CLK/SEG7; optional note for others. */
  label: string;
  /** Propagation delay in time units (glitch view). */
  delay: number;
  /** Number of inputs for AND/OR/NAND/NOR/XOR/XNOR (2–4, default 2). */
  inputs?: number;
  /** Bit width of the arithmetic blocks (1–4, default 4; barrel shifter 2–4). */
  bits?: number;
  /** Barrel shifter direction (default left). */
  dir?: 'left' | 'right';
  /** Drawing only: rotation in degrees (0, 90, 180, 270), clockwise. */
  rot?: number;
  /** Drawing only (blocks): side and position (0–1 along the side) of moved pins, by key i0…, o0…. */
  pinLayout?: Record<string, { side: 'L' | 'R' | 'T' | 'B'; pos: number }>;
  /**
   * Bus width in bits (1–16): IN, CONST, SPLIT, MERGE, REG, and the data
   * width of RAM and ROM. OUT and TUNNEL take the width of what drives them.
   */
  width?: number;
  /** RAM / ROM: address width in bits (1–6). */
  addrBits?: number;
  /** CONST: its value. */
  value?: number;
  /** ROM: contents, one word per address (missing words read 0). */
  data?: number[];
  /** DE2 mode: board resource the part is assigned to (SW3, KEY1, LEDR5, LEDG0, HEX2); automatic when unset. */
  de2?: string;
  /** BLOCK: id of the block in the library, and its pin names (inputs, outputs). */
  ref?: string;
  pinsIn?: string[];
  pinsOut?: string[];
}

export interface Wire {
  id: string;
  from: string;
  /** Output pin of the source node (default 0). */
  fromPin?: number;
  to: string;
  pin: number;
  /**
   * Hand-drawn route (drawing only, no effect on logic): alternating x and y
   * coordinates of the bends, starting and ending with an x — the x values
   * are vertical segments, the y values horizontal ones.
   */
  bends?: number[];
}

export interface Circuit {
  nodes: GateNode[];
  wires: Wire[];
}

export type PartCategory = 'io' | 'wires' | 'logic' | 'plexers' | 'arithmetic' | 'flipflops' | 'memory';

interface PartSpec {
  category: PartCategory;
  ins: string[];
  outs: string[];
  /** Input pin that is the clock (flip-flops). */
  clock?: number;
}

const FF_OUTS = ['Q', 'Q̅'];

export const PARTS: Record<GateType, PartSpec> = {
  IN: { category: 'io', ins: [], outs: [''] },
  OUT: { category: 'io', ins: [''], outs: [] },
  LED: { category: 'io', ins: [''], outs: [] },
  BTN: { category: 'io', ins: [], outs: [''] },
  CLK: { category: 'io', ins: [], outs: [''] },
  CONST0: { category: 'wires', ins: [], outs: [''] },
  CONST1: { category: 'wires', ins: [], outs: [''] },
  TUNNEL: { category: 'wires', ins: [''], outs: [''] },
  BLOCK: { category: 'io', ins: [], outs: [] },
  SEG7: { category: 'io', ins: ['b0', 'b1', 'b2', 'b3'], outs: [] },
  AND: { category: 'logic', ins: ['', ''], outs: [''] },
  OR: { category: 'logic', ins: ['', ''], outs: [''] },
  NOT: { category: 'logic', ins: [''], outs: [''] },
  NAND: { category: 'logic', ins: ['', ''], outs: [''] },
  NOR: { category: 'logic', ins: ['', ''], outs: [''] },
  XOR: { category: 'logic', ins: ['', ''], outs: [''] },
  XNOR: { category: 'logic', ins: ['', ''], outs: [''] },
  BUF: { category: 'logic', ins: [''], outs: [''] },
  MUX2: { category: 'plexers', ins: ['D0', 'D1', 'S'], outs: ['Y'] },
  MUX4: { category: 'plexers', ins: ['D0', 'D1', 'D2', 'D3', 'S0', 'S1'], outs: ['Y'] },
  DEMUX2: { category: 'plexers', ins: ['D', 'S'], outs: ['Y0', 'Y1'] },
  DEMUX4: { category: 'plexers', ins: ['D', 'S0', 'S1'], outs: ['Y0', 'Y1', 'Y2', 'Y3'] },
  DEC2: { category: 'plexers', ins: ['A0', 'A1'], outs: ['Y0', 'Y1', 'Y2', 'Y3'] },
  DEC3: { category: 'plexers', ins: ['A0', 'A1', 'A2'], outs: ['Y0', 'Y1', 'Y2', 'Y3', 'Y4', 'Y5', 'Y6', 'Y7'] },
  BITSEL: { category: 'plexers', ins: ['D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'S0', 'S1', 'S2'], outs: ['Y'] },
  PENC4: { category: 'plexers', ins: ['I0', 'I1', 'I2', 'I3'], outs: ['Q0', 'Q1', 'V'] },
  HA: { category: 'arithmetic', ins: ['A', 'B'], outs: ['S', 'C'] },
  FA: { category: 'arithmetic', ins: ['A', 'B', 'Cin'], outs: ['S', 'Cout'] },
  // Multi-bit blocks: pins depend on the width (see arithPins); these are the 4-bit ones.
  ADD: { category: 'arithmetic', ins: [], outs: [] },
  SUB: { category: 'arithmetic', ins: [], outs: [] },
  MUL: { category: 'arithmetic', ins: [], outs: [] },
  DIV: { category: 'arithmetic', ins: [], outs: [] },
  SHIFT: { category: 'arithmetic', ins: [], outs: [] },
  CMP: { category: 'arithmetic', ins: [], outs: [] },
  NEG: { category: 'arithmetic', ins: [], outs: [] },
  SEXT: { category: 'arithmetic', ins: [], outs: [] },
  BITCNT: { category: 'arithmetic', ins: [], outs: [] },
  DFF: { category: 'flipflops', ins: ['D', 'C'], outs: FF_OUTS, clock: 1 },
  TFF: { category: 'flipflops', ins: ['T', 'C'], outs: FF_OUTS, clock: 1 },
  JKFF: { category: 'flipflops', ins: ['J', 'C', 'K'], outs: FF_OUTS, clock: 1 },
  SRFF: { category: 'flipflops', ins: ['S', 'C', 'R'], outs: FF_OUTS, clock: 1 },
  CONST: { category: 'wires', ins: [], outs: [''] },
  // Splitter and merger pins depend on the width (see inputNames/outputNames).
  SPLIT: { category: 'wires', ins: ['D'], outs: [] },
  MERGE: { category: 'wires', ins: [], outs: ['D'] },
  REG: { category: 'memory', ins: ['D', 'C', 'EN'], outs: ['Q'], clock: 1 },
  RAM: { category: 'memory', ins: ['A', 'D', 'WE', 'C'], outs: ['Q'], clock: 3 },
  ROM: { category: 'memory', ins: ['A'], outs: ['D'] },
};

/** Two-input gates whose input count can be raised to 4. */
export const MULTI_INPUT: GateType[] = ['AND', 'OR', 'NAND', 'NOR', 'XOR', 'XNOR'];
export const GATE_TYPES: GateType[] = ['AND', 'OR', 'NOT', 'NAND', 'NOR', 'XOR', 'XNOR', 'BUF'];
export const FLIP_FLOPS: GateType[] = ['DFF', 'TFF', 'JKFF', 'SRFF'];
/** Nodes whose value the user sets (inputs of the circuit). */
export const SOURCES: GateType[] = ['IN', 'BTN', 'CLK'];
/** Nodes that show a result (outputs of the circuit). */
export const SINKS: GateType[] = ['OUT', 'LED'];

export const PALETTE: Array<{ category: PartCategory; types: GateType[] }> = [
  { category: 'logic', types: GATE_TYPES },
  { category: 'io', types: ['OUT', 'LED', 'IN', 'CLK', 'BTN', 'SEG7'] },
  { category: 'wires', types: ['TUNNEL', 'CONST0', 'CONST1', 'CONST', 'SPLIT', 'MERGE'] },
  { category: 'plexers', types: ['MUX2', 'MUX4', 'DEMUX2', 'DEMUX4', 'DEC2', 'DEC3', 'BITSEL', 'PENC4'] },
  { category: 'arithmetic', types: ['HA', 'FA', 'ADD', 'SUB', 'MUL', 'DIV', 'SHIFT', 'CMP', 'NEG', 'SEXT', 'BITCNT'] },
  { category: 'flipflops', types: FLIP_FLOPS },
  { category: 'memory', types: ['REG', 'RAM', 'ROM'] },
];

/* ── Buses ──────────────────────────────────────────────────────────── */

/** Parts with a bus width setting. */
export const WIDE: GateType[] = ['IN', 'CONST', 'SPLIT', 'MERGE', 'REG', 'RAM', 'ROM'];
/** Clocked parts that hold a value (flip-flops, register, RAM). */
export const CLOCKED: GateType[] = [...FLIP_FLOPS, 'REG', 'RAM'];
export const MAX_WIDTH = 16;
export const MAX_ADDR = 6;

const DEFAULT_WIDTH: Partial<Record<GateType, number>> = { CONST: 4, SPLIT: 4, MERGE: 4, REG: 4, RAM: 4, ROM: 4 };

/** Bus width of a part (1 for everything that has no width setting). */
export function dataWidth(n: Pick<GateNode, 'type' | 'width'>): number {
  if (!WIDE.includes(n.type)) return 1;
  return Math.max(n.type === 'SPLIT' || n.type === 'MERGE' ? 2 : 1, Math.min(MAX_WIDTH, Math.round(n.width ?? DEFAULT_WIDTH[n.type] ?? 1)));
}
export function addrWidth(n: Pick<GateNode, 'addrBits'>): number {
  return Math.max(1, Math.min(MAX_ADDR, Math.round(n.addrBits ?? 3)));
}
export const maskOf = (w: number) => (w >= 31 ? 0x7fffffff : (1 << w) - 1);

/**
 * Width a pin expects or drives, in bits; 0 means "any" (it takes the width
 * of what drives it: outputs, tunnels, block pins).
 */
export function pinWidth(n: GateNode, dir: 'i' | 'o', k: number): number {
  const w = dataWidth(n);
  switch (n.type) {
    case 'IN':
    case 'CONST': return dir === 'o' ? w : 1;
    case 'OUT':
    case 'TUNNEL':
    case 'BUF':
    case 'BLOCK': return 0;
    case 'SPLIT': return dir === 'i' ? w : 1;
    case 'MERGE': return dir === 'o' ? w : 1;
    case 'REG': return (dir === 'i' && k === 0) || dir === 'o' ? w : 1;
    case 'RAM': return dir === 'o' || k === 1 ? w : k === 0 ? addrWidth(n) : 1;
    case 'ROM': return dir === 'o' ? w : addrWidth(n);
    default: return 1;
  }
}

/**
 * Width of every signal, and the wires whose ends disagree. A pin of width
 * "any" (tunnel, buffer, block pin) takes the width of its driver.
 */
export function signalWidths(c: Circuit): { widths: Record<string, number>; mismatched: string[] } {
  const byId = new Map(c.nodes.map((n) => [n.id, n]));
  const into = new Map<string, Wire>();
  c.wires.forEach((w) => into.set(`${w.to}:${w.pin}`, w));
  const widths: Record<string, number> = {};
  const busy = new Set<string>();
  const widthOf = (id: string, pin: number): number => {
    const key = sig(id, pin);
    if (key in widths) return widths[key];
    const n = byId.get(id);
    if (!n) return 1;
    let w = pinWidth(n, 'o', pin);
    if (w === 0) {
      // Pass-through parts take the width of their own input.
      const src = n.type === 'BLOCK' ? undefined : into.get(`${id}:0`);
      if (src && !busy.has(key)) {
        busy.add(key);
        w = widthOf(src.from, src.fromPin ?? 0);
        busy.delete(key);
      } else w = 1;
    }
    widths[key] = w;
    return w;
  };
  for (const n of c.nodes) outputNames(n).forEach((_, pin) => widthOf(n.id, pin));
  // Tunnels without an input read their namesake with one.
  const named = new Map<string, number>();
  for (const n of c.nodes) if (n.type === 'TUNNEL' && into.has(`${n.id}:0`) && n.label.trim()) named.set(n.label.trim(), widths[n.id] ?? 1);
  for (const n of c.nodes) if (n.type === 'TUNNEL' && !into.has(`${n.id}:0`)) widths[n.id] = named.get(n.label.trim()) ?? 1;
  const mismatched: string[] = [];
  for (const w of c.wires) {
    const to = byId.get(w.to);
    if (!to || !byId.has(w.from)) continue;
    const want = pinWidth(to, 'i', w.pin);
    if (want && want !== (widths[sig(w.from, w.fromPin ?? 0)] ?? 1)) mismatched.push(w.id);
  }
  return { widths, mismatched };
}

/** A number as the editor shows a bus value: decimal, and hex for wider buses. */
export function formatBus(v: number, width: number): string {
  if (width <= 1) return String(v);
  return width > 4 ? `0x${v.toString(16).toUpperCase()}` : String(v);
}

export function isFlipFlop(type: GateType): boolean {
  return FLIP_FLOPS.includes(type);
}

export function isGate(type: GateType): boolean {
  return GATE_TYPES.includes(type);
}

/** Multi-bit arithmetic blocks (Digital's Arithmetic menu). */
export const ARITH: GateType[] = ['ADD', 'SUB', 'MUL', 'DIV', 'SHIFT', 'CMP', 'NEG', 'SEXT', 'BITCNT'];

type Shape = Pick<GateNode, 'type'> & Partial<Pick<GateNode, 'inputs' | 'bits' | 'dir' | 'pinsIn' | 'pinsOut' | 'width'>>;

export function bitWidth(n: Shape): number {
  return Math.max(n.type === 'SHIFT' ? 2 : 1, Math.min(4, n.bits ?? 4));
}
const bus = (name: string, k: number) => Array.from({ length: k }, (_, i) => `${name}${i}`);
const shiftBits = (k: number) => Math.max(1, Math.ceil(Math.log2(k)));
const countBits = (k: number) => Math.ceil(Math.log2(k + 1));

/** Input and output pin names of an arithmetic block, least significant bit first. */
export function arithPins(n: Shape): { ins: string[]; outs: string[] } {
  const k = bitWidth(n);
  switch (n.type) {
    case 'ADD': return { ins: [...bus('A', k), ...bus('B', k), 'Cin'], outs: [...bus('S', k), 'Cout'] };
    case 'SUB': return { ins: [...bus('A', k), ...bus('B', k), 'Bin'], outs: [...bus('D', k), 'Bout'] };
    case 'MUL': return { ins: [...bus('A', k), ...bus('B', k)], outs: bus('P', 2 * k) };
    case 'DIV': return { ins: [...bus('A', k), ...bus('B', k)], outs: [...bus('Q', k), ...bus('R', k)] };
    case 'SHIFT': return { ins: [...bus('D', k), ...bus('S', shiftBits(k))], outs: bus('Y', k) };
    case 'CMP': return { ins: [...bus('A', k), ...bus('B', k)], outs: ['GT', 'EQ', 'LT'] };
    case 'NEG': return { ins: bus('D', k), outs: bus('Y', k) };
    case 'SEXT': return { ins: bus('D', k), outs: bus('Y', 2 * k) };
    case 'BITCNT': return { ins: bus('D', k), outs: bus('C', countBits(k)) };
    default: return { ins: [], outs: [] };
  }
}

export function inputNames(n: Shape): string[] {
  if (n.type === 'MERGE') return Array.from({ length: dataWidth(n) }, (_, i) => String(i));
  if (MULTI_INPUT.includes(n.type)) {
    const k = Math.max(2, Math.min(4, n.inputs ?? 2));
    return Array(k).fill('');
  }
  if (ARITH.includes(n.type)) return arithPins(n).ins;
  if (n.type === 'BLOCK') return n.pinsIn ?? [];
  return PARTS[n.type].ins;
}

export function outputNames(n: Shape): string[] {
  if (n.type === 'SPLIT') return Array.from({ length: dataWidth(n) }, (_, i) => String(i));
  if (ARITH.includes(n.type)) return arithPins(n).outs;
  if (n.type === 'BLOCK') return n.pinsOut ?? [];
  return PARTS[n.type].outs;
}

const pack = (bits: number[], from: number, k: number) => bits.slice(from, from + k).reduce((v, b, i) => v | ((b & 1) << i), 0);
const unpack = (v: number, k: number) => Array.from({ length: k }, (_, i) => (v >> i) & 1);

/** Values of an arithmetic block (unsigned; divide by zero gives Q = 0, R = A). */
function arithValue(n: GateNode, ins: number[]): number[] {
  const k = bitWidth(n);
  const mask = (1 << k) - 1;
  const A = pack(ins, 0, k);
  const B = pack(ins, k, k);
  switch (n.type) {
    case 'ADD': return unpack(A + B + (ins[2 * k] ?? 0), k + 1);
    case 'SUB': {
      const d = A - B - (ins[2 * k] ?? 0);
      return [...unpack(d & mask, k), d < 0 ? 1 : 0];
    }
    case 'MUL': return unpack(A * B, 2 * k);
    case 'DIV': return [...unpack(B ? Math.floor(A / B) : 0, k), ...unpack(B ? A % B : A, k)];
    case 'SHIFT': {
      const sh = pack(ins, k, shiftBits(k));
      return unpack((n.dir === 'right' ? A >> sh : A << sh) & mask, k);
    }
    case 'CMP': return [A > B ? 1 : 0, A === B ? 1 : 0, A < B ? 1 : 0];
    case 'NEG': return unpack(-A & mask, k);
    case 'SEXT': return [...unpack(A, k), ...Array(k).fill((A >> (k - 1)) & 1)];
    case 'BITCNT': return unpack(unpack(A, k).reduce((x, y) => x + y, 0), countBits(k));
    default: return [];
  }
}

/** Number of input pins (accepts a node, or a type for the default count). */
export function inputCount(n: GateType | Pick<GateNode, 'type' | 'inputs'>): number {
  return inputNames(typeof n === 'string' ? { type: n } : n).length;
}

export function outputCount(n: GateType | Pick<GateNode, 'type'>): number {
  return outputNames(typeof n === 'string' ? { type: n } : n).length;
}

export function hasOutput(type: GateType): boolean {
  return outputCount(type) > 0;
}

/** Signal key of one output pin. */
export function sig(id: string, pin = 0): string {
  return pin ? `${id}#${pin}` : id;
}

/** Two-input gate function (kept for callers of the old API). */
export function applyGate(type: GateType, a: number, b: number): number {
  return gateValue(type, [a, b]);
}

function gateValue(type: GateType, ins: number[]): number {
  const and = ins.every((v) => v === 1) ? 1 : 0;
  const or = ins.some((v) => v === 1) ? 1 : 0;
  const xor = ins.reduce((x, v) => x ^ (v & 1), 0);
  switch (type) {
    case 'AND': return and;
    case 'OR': return or;
    case 'NAND': return and ^ 1;
    case 'NOR': return or ^ 1;
    case 'XOR': return xor;
    case 'XNOR': return xor ^ 1;
    case 'NOT': return (ins[0] ?? 0) ^ 1;
    default: return ins[0] ?? 0;
  }
}

/** Seven-segment patterns for 0–F, DE2 style: bit i = segment a..g, 0 = lit. */
export const SEG7_PATTERNS = [
  0b1000000, 0b1111001, 0b0100100, 0b0110000, 0b0011001, 0b0010010, 0b0000010, 0b1111000,
  0b0000000, 0b0010000, 0b0001000, 0b0000011, 0b1000110, 0b0100001, 0b0000110, 0b0001110,
];

/** Output values of a node for the given input values (flip-flops: current state). */
export function computeNode(n: GateNode, ins: number[], q = 0, sourceValue = 0): number[] {
  const [a = 0, b = 0, c = 0, d = 0, e = 0, f = 0] = ins;
  switch (n.type) {
    case 'IN': return [dataWidth(n) > 1 ? (sourceValue & maskOf(dataWidth(n))) >>> 0 : sourceValue ? 1 : 0];
    case 'BTN':
    case 'CLK': return [sourceValue ? 1 : 0];
    case 'CONST': return [((n.value ?? 0) & maskOf(dataWidth(n))) >>> 0];
    case 'SPLIT': return Array.from({ length: dataWidth(n) }, (_, i) => (a >>> i) & 1);
    case 'MERGE': return [ins.reduce((v, b, i) => v | ((b & 1) << i), 0) >>> 0];
    case 'REG': return [q];
    case 'ROM': return [((n.data?.[a] ?? 0) & maskOf(dataWidth(n))) >>> 0];
    case 'CONST0': return [0];
    case 'CONST1': return [1];
    case 'OUT':
    case 'LED':
    case 'SEG7': return [];
    case 'MUX2': return [c ? b : a];
    case 'MUX4': return [[a, b, c, d][(f << 1) | e]];
    case 'DEMUX2': return [b ? 0 : a, b ? a : 0];
    case 'DEMUX4': {
      const k = (c << 1) | b;
      return [0, 1, 2, 3].map((i) => (i === k ? a : 0));
    }
    case 'DEC2': {
      const k = (b << 1) | a;
      return [0, 1, 2, 3].map((i) => (i === k ? 1 : 0));
    }
    case 'DEC3': {
      const k = (c << 2) | (b << 1) | a;
      return [0, 1, 2, 3, 4, 5, 6, 7].map((i) => (i === k ? 1 : 0));
    }
    case 'BITSEL': return [ins[((ins[10] ?? 0) << 2) | ((ins[9] ?? 0) << 1) | (ins[8] ?? 0)] ?? 0];
    case 'PENC4': {
      // Highest set input wins; V = any input set.
      const k = d ? 3 : c ? 2 : b ? 1 : 0;
      const any = a | b | c | d;
      return [any ? k & 1 : 0, any ? k >> 1 : 0, any];
    }
    case 'HA': return [a ^ b, a & b];
    case 'FA': return [a ^ b ^ c, (a & b) | (c & (a ^ b))];
    case 'ADD':
    case 'SUB':
    case 'MUL':
    case 'DIV':
    case 'SHIFT':
    case 'CMP':
    case 'NEG':
    case 'SEXT':
    case 'BITCNT': return arithValue(n, ins);
    case 'DFF':
    case 'TFF':
    case 'JKFF':
    case 'SRFF': return [q, q ^ 1];
    case 'TUNNEL': return [ins[0] ?? 0];
    case 'BLOCK': return outputNames(n).map(() => 0);
    default: return [gateValue(n.type, ins)];
  }
}

/** Flip-flop state after a rising clock edge, from the inputs just before it. */
export function nextState(n: GateNode, ins: number[], q: number): number {
  const [x = 0, , y = 0] = ins;
  switch (n.type) {
    case 'DFF': return x;
    case 'TFF': return x ? q ^ 1 : q;
    case 'JKFF': return x && y ? q ^ 1 : x ? 1 : y ? 0 : q;
    // S = R = 1 is not allowed on a real SR flip-flop; here S wins.
    case 'SRFF': return x ? 1 : y ? 0 : q;
    default: return q;
  }
}

export function driverOf(c: Circuit, nodeId: string, pin: number): string | null {
  return c.wires.find((w) => w.to === nodeId && w.pin === pin)?.from ?? null;
}

/** The wire feeding an input pin, if any. */
export function wireInto(c: Circuit, nodeId: string, pin: number): Wire | undefined {
  return c.wires.find((w) => w.to === nodeId && w.pin === pin);
}

export interface Evaluation {
  /** Value of every signal (see `sig`). */
  values: Record<string, number>;
  /** Nodes on a combinational loop, if any (then values are not meaningful). */
  loop: string[];
  /** Inputs with nothing connected (read as 0). */
  floating: Array<{ node: string; pin: number }>;
  /** Input pin values of every node. */
  pins: Record<string, number[]>;
}

/**
 * Settles the combinational logic. `inputs` holds the value of each source
 * node (IN, BTN, CLK) by id; `q` the stored bit of each flip-flop.
 * Flip-flop outputs come from their state, so feedback through a flip-flop
 * is not a loop.
 */
export function evaluate(c: Circuit, inputs: Record<string, number>, q: Record<string, number> = {}): Evaluation {
  const byId = new Map(c.nodes.map((n) => [n.id, n]));
  const into = new Map<string, Wire>();
  c.wires.forEach((w) => into.set(`${w.to}:${w.pin}`, w));
  const outs: Record<string, number[]> = {};
  const state: Record<string, 0 | 1 | 2> = {};
  const loop = new Set<string>();
  const floating: Array<{ node: string; pin: number }> = [];

  const readPin = (id: string, pin: number, stack: string[]): number => {
    const w = into.get(`${id}:${pin}`);
    if (!w || !byId.has(w.from)) {
      // A register's EN may be left open on purpose (it then loads every edge).
      if (!(pin === 2 && byId.get(id)?.type === 'REG')) floating.push({ node: id, pin });
      return 0;
    }
    return visit(w.from, stack)[w.fromPin ?? 0] ?? 0;
  };

  const visit = (id: string, stack: string[]): number[] => {
    const n = byId.get(id)!;
    if (state[id] === 2) return outs[id];
    if (state[id] === 1) {
      stack.slice(stack.indexOf(id)).forEach((x) => loop.add(x));
      return outputNames(n).map(() => 0);
    }
    state[id] = 1;
    let v: number[];
    if (isFlipFlop(n.type) || n.type === 'REG') v = computeNode(n, [], q[id] ?? 0);
    else if (n.type === 'RAM') {
      // Reading is combinational in the address; the data and write pins
      // only matter at the clock edge, like a flip-flop's.
      const addr = readPin(id, 0, [...stack, id]);
      v = [q[`${id}@${addr}`] ?? 0];
    } else {
      const ins = inputNames(n).map((_, pin) => readPin(id, pin, [...stack, id]));
      v = computeNode(n, ins, 0, inputs[id]);
      outs[`${id}@in`] = ins;
    }
    state[id] = 2;
    outs[id] = v;
    return v;
  };
  c.nodes.forEach((n) => visit(n.id, []));
  // Flip-flop, register and RAM inputs are read after the settle (they do not feed back).
  c.nodes.filter((n) => CLOCKED.includes(n.type)).forEach((n) => {
    outs[`${n.id}@in`] = inputNames(n).map((_, pin) => readPin(n.id, pin, [n.id]));
  });

  const values: Record<string, number> = {};
  for (const n of c.nodes) {
    const o = outs[n.id] ?? [];
    o.forEach((v, pin) => { values[sig(n.id, pin)] = v; });
    // OUT and SEG7 show their inputs.
    if (SINKS.includes(n.type)) values[n.id] = outs[`${n.id}@in`]?.[0] ?? 0;
    if (n.type === 'SEG7') {
      const b = outs[`${n.id}@in`] ?? [];
      values[n.id] = (b[0] ?? 0) | ((b[1] ?? 0) << 1) | ((b[2] ?? 0) << 2) | ((b[3] ?? 0) << 3);
    }
  }
  const pins: Record<string, number[]> = {};
  for (const n of c.nodes) pins[n.id] = outs[`${n.id}@in`] ?? [];
  return { values, loop: [...loop], floating: dedupe(floating), pins };
}

function dedupe(list: Array<{ node: string; pin: number }>): Array<{ node: string; pin: number }> {
  const seen = new Set<string>();
  return list.filter((f) => {
    const k = `${f.node}:${f.pin}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}


/* ── Sequential stepping ────────────────────────────────────────────── */

export interface SeqState {
  /** Stored bit of each flip-flop. */
  q: Record<string, number>;
  /** Clock pin level of each flip-flop at the last settle (edge detection). */
  clk: Record<string, number>;
}

export const EMPTY_SEQ: SeqState = { q: {}, clk: {} };

/**
 * Applies `inputs`, then lets every flip-flop whose clock pin went 0 → 1
 * take its next state, repeating while outputs keep clocking other
 * flip-flops (ripple counters). Returns the settled evaluation and state.
 */
export function settle(c: Circuit, inputs: Record<string, number>, seq: SeqState = EMPTY_SEQ): { ev: Evaluation; seq: SeqState } {
  const ffs = c.nodes.filter((n) => CLOCKED.includes(n.type));
  let q: Record<string, number> = {};
  ffs.forEach((f) => { q[f.id] = seq.q[f.id] ?? 0; });
  // RAM words are stored as `id@address`.
  const rams = new Set(ffs.filter((f) => f.type === 'RAM').map((f) => `${f.id}@`));
  if (rams.size) for (const [k, v] of Object.entries(seq.q)) if (rams.has(k.slice(0, k.indexOf('@') + 1))) q[k] = v;
  const enabled = (f: GateNode) => f.type !== 'REG' || !wireInto(c, f.id, 2);
  const clk: Record<string, number> = { ...seq.clk };
  // A flip-flop seen for the first time takes the clock level of the circuit
  // at rest (every CLK low), so the first clock pulse after adding it counts
  // and flip-flops clocked by other flip-flops do not fire spuriously.
  const unknown = ffs.filter((f) => !(f.id in clk));
  if (unknown.length) {
    const rest = { ...inputs };
    c.nodes.filter((n) => n.type === 'CLK').forEach((n) => { rest[n.id] = 0; });
    const base = evaluate(c, rest, q);
    unknown.forEach((f) => { clk[f.id] = base.pins[f.id]?.[PARTS[f.type].clock!] ?? 0; });
  }
  let ev = evaluate(c, inputs, q);
  for (let iter = 0; iter < 32 && ffs.length; iter++) {
    const pins = ev.pins;
    const next = { ...q };
    let changed = false;
    for (const f of ffs) {
      const ins = pins[f.id] ?? [];
      const level = ins[PARTS[f.type].clock!] ?? 0;
      const prev = clk[f.id];
      clk[f.id] = level;
      if (prev === 0 && level === 1) {
        if (f.type === 'RAM') {
          // Write D to address A while WE is high.
          if (ins[2]) {
            const key = `${f.id}@${ins[0] ?? 0}`;
            const word = ((ins[1] ?? 0) & maskOf(dataWidth(f))) >>> 0;
            if ((next[key] ?? 0) !== word) {
              next[key] = word;
              changed = true;
            }
          }
          continue;
        }
        // A register loads while EN is high; an unconnected EN means always.
        const nq = f.type === 'REG' ? (ins[2] || enabled(f) ? ((ins[0] ?? 0) & maskOf(dataWidth(f))) >>> 0 : q[f.id] ?? 0) : nextState(f, ins, q[f.id] ?? 0);
        if (nq !== next[f.id]) {
          next[f.id] = nq;
          changed = true;
        }
      }
    }
    if (!changed) break;
    q = next;
    ev = evaluate(c, inputs, q);
  }
  // Record clock levels that the last evaluation produced.
  const pins = ev.pins;
  for (const f of ffs) clk[f.id] = pins[f.id]?.[PARTS[f.type].clock!] ?? 0;
  return { ev, seq: { q, clk } };
}

/* ── Unit-delay timing simulation ───────────────────────────────────── */

export interface Trace {
  /** Value changes per signal (see `sig`): [time, value] pairs, first at t=0. */
  changes: Record<string, Array<[number, number]>>;
  end: number;
  /** Nodes with an output that changed more than once (a glitch). */
  glitches: string[];
}

/**
 * Starting from the steady state for `before`, apply `after` at t = 0 and let
 * every part update `delay` time units after one of its inputs changes
 * (transport delay). Flip-flops keep the state `q` (no clocking here).
 */
export function simulateTiming(
  c: Circuit,
  before: Record<string, number>,
  after: Record<string, number>,
  maxTime = 60,
  q: Record<string, number> = {},
): Trace {
  const steady = evaluate(c, before, q).values;
  const value: Record<string, number> = { ...steady };
  const changes: Record<string, Array<[number, number]>> = {};
  const byId = new Map(c.nodes.map((n) => [n.id, n]));
  for (const n of c.nodes) {
    if (SINKS.includes(n.type) || n.type === 'SEG7') changes[n.id] = [[0, steady[n.id] ?? 0]];
    outputNames(n).forEach((_, pin) => { changes[sig(n.id, pin)] = [[0, steady[sig(n.id, pin)] ?? 0]]; });
  }
  const fanout = new Map<string, string[]>();
  c.wires.forEach((w) => {
    const k = sig(w.from, w.fromPin ?? 0);
    fanout.set(k, [...(fanout.get(k) ?? []), w.to]);
  });

  const queue = new Map<number, Set<string>>();
  const schedule = (t: number, nid: string) => {
    if (t > maxTime) return;
    if (!queue.has(t)) queue.set(t, new Set());
    queue.get(t)!.add(nid);
  };
  const set = (key: string, v: number, t: number) => {
    if (value[key] === v) return;
    value[key] = v;
    (changes[key] ??= [[0, v]]).push([t, v]);
    for (const dst of fanout.get(key) ?? []) {
      const d = byId.get(dst);
      if (!d) continue;
      schedule(t + (SINKS.includes(d.type) || d.type === 'SEG7' ? 0 : Math.max(1, d.delay)), dst);
    }
  };
  const input = (nid: string, pin: number) => {
    const w = wireInto(c, nid, pin);
    return w ? value[sig(w.from, w.fromPin ?? 0)] ?? 0 : 0;
  };
  const update = (n: GateNode, t: number) => {
    const ins = inputNames(n).map((_, pin) => input(n.id, pin));
    if (SINKS.includes(n.type)) return set(n.id, ins[0] ?? 0, t);
    if (n.type === 'SEG7') return set(n.id, (ins[0] ?? 0) | ((ins[1] ?? 0) << 1) | ((ins[2] ?? 0) << 2) | ((ins[3] ?? 0) << 3), t);
    if (n.type === 'RAM') return set(n.id, q[`${n.id}@${ins[0] ?? 0}`] ?? 0, t);
    if (CLOCKED.includes(n.type)) return;
    computeNode(n, ins, 0, after[n.id]).forEach((v, pin) => set(sig(n.id, pin), v, t));
  };

  let end = 0;
  c.nodes.filter((n) => SOURCES.includes(n.type)).forEach((n) => set(n.id, computeNode(n, [], 0, after[n.id] ?? 0)[0] ?? 0, 0));
  for (let t = 0; t <= maxTime; t++) {
    for (let pass = 0; pass < 2; pass++) {
      const due = queue.get(t);
      if (!due) break;
      queue.delete(t);
      for (const nid of due) {
        update(byId.get(nid)!, t);
        end = Math.max(end, t);
      }
    }
  }
  const glitchy = new Set<string>();
  for (const [key, list] of Object.entries(changes)) {
    const nid = key.split('#')[0];
    const n = byId.get(nid);
    if (n && !SOURCES.includes(n.type) && list.length > 2) glitchy.add(nid);
  }
  return { changes, end: Math.max(end, 1), glitches: [...glitchy] };
}

/** Value of a signal at time t from its change list. */
export function valueAt(list: Array<[number, number]>, t: number): number {
  let v = list[0]?.[1] ?? 0;
  for (const [ct, cv] of list) {
    if (ct <= t) v = cv;
    else break;
  }
  return v;
}

/* ── Truth table and Verilog ────────────────────────────────────────── */

const byPos = (a: GateNode, b: GateNode) => a.y - b.y || a.x - b.x;

/** Inputs (IN, BTN, CLK) and outputs (OUT) ordered top to bottom. */
export function ioNodes(c: Circuit): { ins: GateNode[]; outs: GateNode[]; displays: GateNode[] } {
  return {
    ins: c.nodes.filter((n) => SOURCES.includes(n.type)).sort(byPos),
    outs: c.nodes.filter((n) => SINKS.includes(n.type)).sort(byPos),
    displays: c.nodes.filter((n) => n.type === 'SEG7').sort(byPos),
  };
}

export function isSequential(c: Circuit): boolean {
  return c.nodes.some((n) => CLOCKED.includes(n.type));
}

export function truthTable(c: Circuit, maxInputs = 6): { ins: GateNode[]; outs: GateNode[]; rows: Array<{ in: number[]; out: number[] }> } | null {
  if (isSequential(c)) return null;
  const { ins, outs, displays } = ioNodes(c);
  const shown = [...outs, ...displays];
  // A bus input counts once per bit.
  const widths = ins.map((n) => dataWidth(n));
  const total = widths.reduce((x, y) => x + y, 0);
  if (ins.length === 0 || total > maxInputs) return null;
  const rows = [];
  for (let combo = 0; combo < 1 << total; combo++) {
    const iv: Record<string, number> = {};
    let shift = total;
    const bits = ins.map((n, i) => {
      shift -= widths[i];
      const b = (combo >> shift) & maskOf(widths[i]);
      iv[n.id] = b;
      return b;
    });
    const ev = evaluate(c, iv);
    rows.push({ in: bits, out: shown.map((o) => ev.values[o.id] ?? 0) });
  }
  return { ins, outs: shown, rows };
}

const VERILOG_KEYWORDS = new Set(['module', 'endmodule', 'input', 'output', 'wire', 'logic', 'reg', 'assign', 'always', 'always_ff', 'always_comb', 'posedge', 'negedge', 'begin', 'end', 'if', 'else', 'case', 'endcase', 'default', 'and', 'or', 'not', 'xor', 'nand', 'nor', 'xnor', 'buf', 'initial']);

export function sanitizeName(raw: string, fallback: string): string {
  let s = (raw || '').trim().replace(/[çÇğĞıİöÖşŞüÜ]/g, (ch) => ({ ç: 'c', Ç: 'C', ğ: 'g', Ğ: 'G', ı: 'i', İ: 'I', ö: 'o', Ö: 'O', ş: 's', Ş: 'S', ü: 'u', Ü: 'U' })[ch] ?? ch);
  s = s.replace(/[^A-Za-z0-9_]/g, '_');
  if (!/^[A-Za-z_]/.test(s)) s = `n_${s}`;
  if (!s || s === 'n_' || VERILOG_KEYWORDS.has(s)) s = fallback;
  return s;
}

const NET_PREFIX: Partial<Record<GateType, string>> = {
  CONST: 'k', SPLIT: 'split', MERGE: 'bus', REG: 'reg', RAM: 'ram', ROM: 'rom',
  ADD: 'add', SUB: 'sub', MUL: 'mul', DIV: 'div', SHIFT: 'shift', CMP: 'cmp', NEG: 'neg', SEXT: 'sext', BITCNT: 'cnt', MUX2: 'mux', MUX4: 'mux', DEMUX2: 'demux', DEMUX4: 'demux', DEC2: 'dec', DEC3: 'dec', BITSEL: 'bitsel', PENC4: 'penc', HA: 'ha', FA: 'fa', DFF: 'dff', TFF: 'tff', JKFF: 'jk', SRFF: 'sr', CONST0: 'c0', CONST1: 'c1',
};

const OUT_SUFFIX: Partial<Record<GateType, string[]>> = {
  MUX2: ['y'], MUX4: ['y'], DEMUX2: ['y0', 'y1'], DEMUX4: ['y0', 'y1', 'y2', 'y3'], DEC2: ['y0', 'y1', 'y2', 'y3'], DEC3: ['y0', 'y1', 'y2', 'y3', 'y4', 'y5', 'y6', 'y7'], BITSEL: ['y'], PENC4: ['q0', 'q1', 'v'], HA: ['s', 'c'], FA: ['s', 'cout'], DFF: ['q', 'qn'], TFF: ['q', 'qn'], JKFF: ['q', 'qn'], SRFF: ['q', 'qn'],
};

type Mode = 'generic' | 'de2';

/* ── DE2 pin assignment ─────────────────────────────────────────────── */

export type De2Bank = 'SW' | 'KEY' | 'LEDR' | 'LEDG' | 'HEX' | 'CLOCK_50';
export const DE2_BANKS: Record<Exclude<De2Bank, 'CLOCK_50'>, number> = { SW: 18, KEY: 4, LEDR: 18, LEDG: 9, HEX: 8 };

/** Where one part sits on the board: `width` consecutive resources from `start`. */
export interface De2Slot {
  bank: De2Bank;
  start: number;
  width: number;
  /** True when the part's own choice (GateNode.de2) was used. */
  chosen: boolean;
}

/** Banks a part may use, best first. */
export function de2Banks(n: GateNode): Exclude<De2Bank, 'CLOCK_50'>[] {
  switch (n.type) {
    case 'IN': return ['SW', 'KEY'];
    case 'BTN': return ['KEY', 'SW'];
    case 'OUT': return ['LEDR', 'LEDG'];
    case 'LED': return ['LEDG', 'LEDR'];
    case 'SEG7': return ['HEX'];
    default: return [];
  }
}

export function parseDe2(text: string | undefined): { bank: Exclude<De2Bank, 'CLOCK_50'>; index: number } | null {
  const m = /^(SW|KEY|LEDR|LEDG|HEX)(\d+)$/.exec((text ?? '').trim().toUpperCase());
  if (!m) return null;
  const bank = m[1] as Exclude<De2Bank, 'CLOCK_50'>;
  const index = parseInt(m[2], 10);
  return index < DE2_BANKS[bank] ? { bank, index } : null;
}

/**
 * Board resources for every input, output and display. Parts with a valid
 * choice of their own (GateNode.de2) get it first; the rest take the first
 * free run of their preferred bank, top to bottom. A part that does not fit
 * anywhere is left out (it becomes a plain port). `widths` gives an output's
 * bus width.
 */
export function de2Assignment(c: Circuit, widths: Record<string, number> = signalWidths(c).widths): Record<string, De2Slot | null> {
  const { ins, outs, displays } = ioNodes(c);
  const into = (id: string) => wireInto(c, id, 0);
  const widthOf = (n: GateNode) => {
    if (n.type === 'IN') return dataWidth(n);
    if (n.type === 'OUT') {
      const w = into(n.id);
      return w ? widths[sig(w.from, w.fromPin ?? 0)] ?? 1 : 1;
    }
    return 1;
  };
  const used: Record<string, boolean[]> = Object.fromEntries(Object.entries(DE2_BANKS).map(([b, k]) => [b, Array(k).fill(false)]));
  const free = (bank: Exclude<De2Bank, 'CLOCK_50'>, start: number, width: number) =>
    start >= 0 && start + width <= DE2_BANKS[bank] && used[bank].slice(start, start + width).every((x) => !x);
  const take = (bank: Exclude<De2Bank, 'CLOCK_50'>, start: number, width: number) => { for (let k = 0; k < width; k++) used[bank][start + k] = true; };
  const out: Record<string, De2Slot | null> = {};
  const all = [...ins, ...outs, ...displays];
  for (const n of all) {
    if (n.type === 'CLK') { out[n.id] = { bank: 'CLOCK_50', start: 0, width: 1, chosen: false }; continue; }
    const want = parseDe2(n.de2);
    const width = widthOf(n);
    if (want && de2Banks(n).includes(want.bank) && free(want.bank, want.index, width)) {
      take(want.bank, want.index, width);
      out[n.id] = { bank: want.bank, start: want.index, width, chosen: true };
    }
  }
  for (const n of all) {
    if (n.id in out) continue;
    const width = widthOf(n);
    out[n.id] = null;
    for (const bank of de2Banks(n)) {
      const start = used[bank].findIndex((_, k) => free(bank, k, width));
      if (start >= 0) {
        take(bank, start, width);
        out[n.id] = { bank, start, width, chosen: false };
        break;
      }
    }
  }
  return out;
}

interface Built {
  code: string;
  /** Board mapping notes (DE2 mode). */
  notes: string[];
}

function buildVerilog(c: Circuit, moduleName: string, mode: Mode): Built {
  const { ins, outs, displays } = ioNodes(c);
  const names = new Map<string, string>(); // sig -> net name
  const used = new Set<string>();
  const unique = (base: string) => {
    let n = base;
    let k = 2;
    while (used.has(n) || VERILOG_KEYWORDS.has(n)) n = `${base}_${k++}`;
    used.add(n);
    return n;
  };
  const ports: string[] = [];
  const body: string[] = [];
  const notes: string[] = [];

  const { widths } = signalWidths(c);
  const widthOfSig = (key: string) => widths[key] ?? 1;
  const vecDecl = (w: number) => (w > 1 ? `[${w - 1}:0] ` : '');
  const slots = mode === 'de2' ? de2Assignment(c, widths) : {};
  const bankPins = (bank: De2Bank, start: number, width: number) => Array.from({ length: width }, (_, k) => `${bank}${start + k}`);
  let clockPort: string | null = null;

  for (const [i, n] of ins.entries()) {
    const fallback = n.type === 'CLK' ? 'clk' : n.type === 'BTN' ? `btn${i}` : `in${i}`;
    const label = sanitizeName(n.label, fallback);
    const w = dataWidth(n);
    const slot = slots[n.id];
    if (mode === 'de2' && slot) {
      if (slot.bank === 'CLOCK_50') {
        if (!clockPort) {
          clockPort = unique('CLOCK_50');
          ports.push(`    input  logic ${clockPort}`);
          notes.push(`//   CLOCK_50 = ${label} (use Run or Clock step on the board)`);
        }
        names.set(n.id, clockPort);
        continue;
      }
      const pins = bankPins(slot.bank, slot.start, w).map((x) => unique(x));
      pins.forEach((x) => ports.push(`    input  logic ${x}`));
      const activeLow = slot.bank === 'KEY';
      if (w === 1 && !activeLow) {
        names.set(n.id, pins[0]);
      } else {
        const net = unique(label);
        const bits = pins.map((x) => (activeLow ? `~${x}` : x));
        body.push(`    logic ${vecDecl(w)}${net};`, `    assign ${net} = ${w > 1 ? `{${[...bits].reverse().join(', ')}}` : bits[0]};${activeLow ? '  // DE2 keys are active-low' : ''}`);
        names.set(n.id, net);
      }
      const range = w > 1 ? `${pins[w - 1]}..${pins[0]}` : pins[0];
      notes.push(`//   ${range} = ${label}${activeLow ? ' (pressed = 1)' : ''}`);
    } else {
      const p = unique(label);
      ports.push(`    input  logic ${vecDecl(w)}${p}`);
      names.set(n.id, p);
    }
  }

  const outPorts: Array<{ node: GateNode; ports: string[] }> = [];
  for (const [i, n] of outs.entries()) {
    const label = sanitizeName(n.label, `out${i}`);
    const w0 = wireInto(c, n.id, 0);
    const w = w0 ? widthOfSig(sig(w0.from, w0.fromPin ?? 0)) : 1;
    const slot = slots[n.id];
    if (mode === 'de2' && slot) {
      // DE2: one scalar port per LED, bit 0 on the lowest-numbered one.
      const pins = bankPins(slot.bank, slot.start, w).map((x) => unique(x));
      pins.forEach((x) => ports.push(`    output logic ${x}`));
      notes.push(`//   ${w > 1 ? `${pins[w - 1]}..${pins[0]}` : pins[0]} = ${label}`);
      outPorts.push({ node: n, ports: pins });
    } else {
      const p = unique(label);
      ports.push(`    output logic ${vecDecl(w)}${p}`);
      outPorts.push({ node: n, ports: [p] });
    }
  }
  const segPorts: Array<{ node: GateNode; port: string }> = [];
  for (const [i, n] of displays.entries()) {
    const label = sanitizeName(n.label, `hex${i}`);
    const slot = slots[n.id];
    const p = unique(mode === 'de2' && slot ? `HEX${slot.start}` : label);
    if (mode === 'de2') notes.push(`//   ${p} = ${label} (7-segment)`);
    ports.push(`    output logic [6:0] ${p}`);
    segPorts.push({ node: n, port: p });
  }

  // Internal nets, left to right.
  const parts = c.nodes.filter((n) => !SOURCES.includes(n.type) && !SINKS.includes(n.type) && n.type !== 'SEG7').sort((a, b) => a.x - b.x || a.y - b.y);
  const counters: Record<string, number> = {};
  for (const n of parts) {
    const prefix = NET_PREFIX[n.type] ?? 'g';
    counters[prefix] = (counters[prefix] ?? 0) + 1;
    const base = `${prefix}${counters[prefix]}`;
    const suffix = OUT_SUFFIX[n.type] ?? (ARITH.includes(n.type) ? outputNames(n).map((x) => x.toLowerCase()) : undefined);
    outputNames(n).forEach((_, pin) => names.set(sig(n.id, pin), unique(suffix ? `${base}_${suffix[pin]}` : base)));
  }

  const src = (nid: string, pin: number) => {
    const w = wireInto(c, nid, pin);
    const zero = () => {
      const node = c.nodes.find((x) => x.id === nid);
      const pw = node ? pinWidth(node, 'i', pin) : 1;
      return pw > 1 ? `${pw}'d0` : "1'b0";
    };
    return w ? names.get(sig(w.from, w.fromPin ?? 0)) ?? zero() : zero();
  };

  // Internal nets, grouped by width.
  const byWidth = new Map<number, string[]>();
  for (const n of parts) outputNames(n).forEach((_, pin) => {
    const w = widthOfSig(sig(n.id, pin));
    byWidth.set(w, [...(byWidth.get(w) ?? []), names.get(sig(n.id, pin))!]);
  });
  for (const [w, list] of [...byWidth.entries()].sort((a, b) => a[0] - b[0])) body.push(`    logic ${vecDecl(w)}${list.join(', ')};`);
  body.push('');

  const ops: Partial<Record<GateType, string>> = { AND: ' & ', OR: ' | ', NAND: ' & ', NOR: ' | ', XOR: ' ^ ', XNOR: ' ^ ' };
  for (const n of parts) {
    const net = (pin = 0) => names.get(sig(n.id, pin))!;
    const i = (pin: number) => src(n.id, pin);
    switch (n.type) {
      case 'CONST0': body.push(`    assign ${net()} = 1'b0;`); break;
      case 'CONST': {
        const w = dataWidth(n);
        body.push(`    assign ${net()} = ${w}'d${((n.value ?? 0) & maskOf(w)) >>> 0};  // constant`);
        break;
      }
      case 'SPLIT': {
        const w = dataWidth(n);
        const from = wireInto(c, n.id, 0) ? i(0) : null;
        body.push(`    // splitter: ${w}-bit bus to single bits`);
        for (let k = 0; k < w; k++) body.push(`    assign ${net(k)} = ${from ? `${from}[${k}]` : "1'b0"};`);
        break;
      }
      case 'MERGE': {
        const w = dataWidth(n);
        body.push(`    assign ${net()} = {${Array.from({ length: w }, (_, k) => i(w - 1 - k)).join(', ')}};  // merger: bits to a ${w}-bit bus`);
        break;
      }
      case 'REG': {
        const clk = wireInto(c, n.id, 1) ? i(1) : null;
        const en = wireInto(c, n.id, 2) ? i(2) : null;
        const q = net();
        if (!clk) {
          body.push(`    // register ${q}: clock input not connected, it keeps its value`);
          break;
        }
        body.push(`    // ${dataWidth(n)}-bit register${en ? ' with enable' : ''}`, `    always_ff @(posedge ${clk}) begin`);
        if (en) body.push(`        if (${en}) begin`, `            ${q} <= ${i(0)};`, '        end');
        else body.push(`        ${q} <= ${i(0)};`);
        body.push('    end');
        break;
      }
      case 'ROM': {
        const w = dataWidth(n);
        const aw = addrWidth(n);
        body.push(`    // ROM, ${1 << aw} words of ${w} bits`, '    always_comb begin', `        case (${i(0)})`);
        for (let k = 0; k < 1 << aw; k++) body.push(`            ${aw}'d${k}: ${net()} = ${w}'h${(((n.data?.[k] ?? 0) & maskOf(w)) >>> 0).toString(16).toUpperCase()};`);
        body.push(`            default: ${net()} = ${w}'d0;`, '        endcase', '    end');
        break;
      }
      case 'RAM': {
        const w = dataWidth(n);
        const aw = addrWidth(n);
        const words = Array.from({ length: 1 << aw }, (_, k) => unique(`${net()}_m${k}`));
        const clk = wireInto(c, n.id, 3) ? i(3) : null;
        body.push(`    // RAM, ${1 << aw} words of ${w} bits: written on the clock edge while WE is high, read at any time`);
        body.push(`    logic ${vecDecl(w)}${words.join(', ')};`);
        if (clk) {
          body.push(`    always_ff @(posedge ${clk}) begin`, `        if (${i(2)}) begin`, `            case (${i(0)})`);
          words.forEach((m, k) => body.push(`                ${aw}'d${k}: ${m} <= ${i(1)};`));
          body.push('            endcase', '        end', '    end');
        } else body.push('    // clock input not connected: nothing is ever written');
        body.push('    always_comb begin', `        case (${i(0)})`);
        words.forEach((m, k) => body.push(`            ${aw}'d${k}: ${net()} = ${m};`));
        body.push(`            default: ${net()} = ${w}'d0;`, '        endcase', '    end');
        break;
      }
      case 'CONST1': body.push(`    assign ${net()} = 1'b1;`); break;
      case 'NOT': body.push(`    assign ${net()} = ~${i(0)};  // NOT`); break;
      case 'BUF': body.push(`    assign ${net()} = ${i(0)};  // buffer`); break;
      case 'MUX2': body.push(`    assign ${net()} = ${i(2)} ? ${i(1)} : ${i(0)};  // 2:1 mux`); break;
      case 'MUX4': body.push(`    assign ${net()} = ${i(5)} ? (${i(4)} ? ${i(3)} : ${i(2)}) : (${i(4)} ? ${i(1)} : ${i(0)});  // 4:1 mux`); break;
      case 'DEMUX2':
        body.push(`    // 1-to-2 demultiplexer`, `    assign ${net(0)} = ${i(0)} & ~${i(1)};`, `    assign ${net(1)} = ${i(0)} &  ${i(1)};`);
        break;
      case 'DEMUX4':
        body.push(`    // 1-to-4 demultiplexer`);
        [0, 1, 2, 3].forEach((k) => body.push(`    assign ${net(k)} = ${i(0)} & ${k & 2 ? ' ' : '~'}${i(2)} & ${k & 1 ? ' ' : '~'}${i(1)};`));
        break;
      case 'DEC3':
        body.push(`    // 3-to-8 decoder`);
        [0, 1, 2, 3, 4, 5, 6, 7].forEach((k) => body.push(`    assign ${net(k)} = ${k & 4 ? ' ' : '~'}${i(2)} & ${k & 2 ? ' ' : '~'}${i(1)} & ${k & 1 ? ' ' : '~'}${i(0)};`));
        break;
      case 'BITSEL': {
        // 8-to-1 bit selector: pick D[S] from an 8-bit input.
        const pick = (lo: number, bits: number[]): string =>
          bits.length === 0 ? i(lo) : `${i(8 + bits.length - 1)} ? (${pick(lo + (1 << (bits.length - 1)), bits.slice(1))}) : (${pick(lo, bits.slice(1))})`;
        body.push(`    assign ${net()} = ${pick(0, [2, 1, 0])};  // bit selector`);
        break;
      }
      case 'PENC4':
        body.push(`    // 4-to-2 priority encoder (highest input wins), v = any input set`);
        body.push(`    assign ${net(0)} = ${i(3)} | (~${i(2)} & ${i(1)});`, `    assign ${net(1)} = ${i(3)} | ${i(2)};`, `    assign ${net(2)} = ${i(0)} | ${i(1)} | ${i(2)} | ${i(3)};`);
        break;
      case 'DEC2':
        body.push(`    // 2-to-4 decoder`);
        body.push(`    assign ${net(0)} = ~${i(1)} & ~${i(0)};`, `    assign ${net(1)} = ~${i(1)} &  ${i(0)};`, `    assign ${net(2)} =  ${i(1)} & ~${i(0)};`, `    assign ${net(3)} =  ${i(1)} &  ${i(0)};`);
        break;
      case 'HA': body.push(`    assign ${net(0)} = ${i(0)} ^ ${i(1)};  // half adder sum`, `    assign ${net(1)} = ${i(0)} & ${i(1)};  // half adder carry`); break;
      case 'ADD':
      case 'SUB':
      case 'MUL':
      case 'DIV':
      case 'SHIFT':
      case 'CMP':
      case 'NEG':
      case 'SEXT':
      case 'BITCNT': {
        const k = bitWidth(n);
        const vec = (from: number, len: number) => (len === 1 ? i(from) : `{${Array.from({ length: len }, (_, j) => i(from + len - 1 - j)).join(', ')}}`);
        const base = net(0).replace(/_[a-z]+0$/, '');
        const A = unique(`${base}_a`);
        const B = unique(`${base}_b`);
        const r = unique(`${base}_r`);
        const outs = outputNames(n);
        const declare = (name: string, width: number) => body.push(`    logic ${width > 1 ? `[${width - 1}:0] ` : ''}${name};`);
        const bitsOut = (vecName: string, from: number, count: number, first = 0) => {
          for (let j = 0; j < count; j++) body.push(`    assign ${net(from + j)} = ${vecName}[${first + j}];`);
        };
        body.push(`    // ${k}-bit ${n.type === 'SHIFT' ? `barrel shifter (${n.dir === 'right' ? 'right' : 'left'})` : n.type.toLowerCase()}`);
        declare(A, k);
        body.push(`    assign ${A} = ${vec(0, k)};`);
        if (n.type === 'SEXT') {
          for (let j = 0; j < 2 * k; j++) body.push(`    assign ${net(j)} = ${A}[${Math.min(j, k - 1)}];`);
          break;
        }
        if (n.type === 'NEG') {
          declare(r, k);
          body.push(`    assign ${r} = 0 - ${A};  // two's complement`);
          bitsOut(r, 0, k);
          break;
        }
        if (n.type === 'BITCNT') {
          const w = outs.length;
          declare(r, w);
          body.push(`    assign ${r} = ${Array.from({ length: k }, (_, j) => i(j)).join(' + ')};`);
          bitsOut(r, 0, w);
          break;
        }
        if (n.type === 'SHIFT') {
          const sw = inputNames(n).length - k;
          declare(B, sw);
          body.push(`    assign ${B} = ${vec(k, sw)};`);
          declare(r, k);
          body.push(`    assign ${r} = ${A} ${n.dir === 'right' ? '>>' : '<<'} ${B};`);
          bitsOut(r, 0, k);
          break;
        }
        declare(B, k);
        body.push(`    assign ${B} = ${vec(k, k)};`);
        if (n.type === 'ADD') {
          declare(r, k + 1);
          body.push(`    assign ${r} = ${A} + ${B} + ${i(2 * k)};`);
          bitsOut(r, 0, k + 1);
        } else if (n.type === 'SUB') {
          declare(r, k + 1);
          body.push(`    assign ${r} = ${A} - ${B} - ${i(2 * k)};  // bit ${k} = borrow`);
          bitsOut(r, 0, k + 1);
        } else if (n.type === 'MUL') {
          declare(r, 2 * k);
          // Shift-and-add: one partial product per bit of B.
          body.push(`    assign ${r} = ${Array.from({ length: k }, (_, j) => `(${B}[${j}] ? (${A} << ${j}) : 0)`).join(' + ')};`);
          bitsOut(r, 0, 2 * k);
        } else if (n.type === 'DIV') {
          // Restoring division, most significant bit first: shift in the
          // next bit of A, subtract B when it fits. Divide by zero gives Q = 0, R = A.
          body.push(`    logic ${base}_nz;`, `    assign ${base}_nz = ${B} != 0;`);
          let prev = '0';
          for (let j = k - 1; j >= 0; j--) {
            const t = unique(`${base}_t${j}`);
            const rj = unique(`${base}_r${j}`);
            declare(t, k + 1);
            declare(rj, k + 1);
            body.push(`    assign ${t} = (${prev} << 1) | ${A}[${j}];`);
            body.push(`    assign ${net(j)} = ${base}_nz & (${t} >= ${B});`);
            body.push(`    assign ${rj} = (${t} >= ${B}) ? ${t} - ${B} : ${t};`);
            prev = rj;
          }
          for (let j = 0; j < k; j++) body.push(`    assign ${net(k + j)} = ${prev}[${j}];`);
        } else if (n.type === 'CMP') {
          body.push(`    assign ${net(0)} = ${A} > ${B};`, `    assign ${net(1)} = ${A} == ${B};`, `    assign ${net(2)} = ${A} < ${B};`);
        }
        break;
      }
      case 'FA':
        body.push(`    assign ${net(0)} = ${i(0)} ^ ${i(1)} ^ ${i(2)};  // full adder sum`);
        body.push(`    assign ${net(1)} = (${i(0)} & ${i(1)}) | (${i(2)} & (${i(0)} ^ ${i(1)}));  // full adder carry`);
        break;
      case 'DFF':
      case 'TFF':
      case 'JKFF':
      case 'SRFF': {
        const clk = wireInto(c, n.id, 1) ? i(1) : null;
        const q = net(0);
        const next =
          n.type === 'DFF' ? i(0)
          : n.type === 'TFF' ? `${q} ^ ${i(0)}`
          : n.type === 'JKFF' ? `(${i(0)} & ~${q}) | (~${i(2)} & ${q})`
          : `${i(0)} | (~${i(2)} & ${q})`;
        if (clk) body.push(`    always_ff @(posedge ${clk}) ${q} <= ${next};  // ${n.type}`);
        else body.push(`    // ${n.type} ${q}: clock input not connected, it keeps its value`);
        body.push(`    assign ${net(1)} = ~${q};`);
        break;
      }
      default: {
        const list = inputNames(n).map((_, pin) => i(pin));
        const joined = list.join(ops[n.type] ?? ' & ');
        const inverted = n.type === 'NAND' || n.type === 'NOR' || n.type === 'XNOR';
        body.push(`    assign ${net()} = ${inverted ? `~(${joined})` : joined};  // ${n.type}`);
      }
    }
  }
  if (parts.length) body.push('');
  for (const { node, ports: list } of outPorts) {
    const from = src(node.id, 0);
    if (list.length === 1) body.push(`    assign ${list[0]} = ${from};`);
    else list.forEach((p, k) => body.push(`    assign ${p} = ${wireInto(c, node.id, 0) ? `${from}[${k}]` : "1'b0"};`));
  }
  for (const { node, port } of segPorts) {
    const v = unique(`${port}_value`);
    body.push('', `    // 7-segment decoder, segments a..g = ${port}[0..6], active-low as on the DE2`);
    body.push(`    logic [3:0] ${v};`);
    body.push(`    assign ${v} = {${src(node.id, 3)}, ${src(node.id, 2)}, ${src(node.id, 1)}, ${src(node.id, 0)}};`);
    body.push('    always_comb begin');
    body.push(`        case (${v})`);
    SEG7_PATTERNS.forEach((pat, k) => body.push(`            4'h${k.toString(16).toUpperCase()}: ${port} = 7'b${pat.toString(2).padStart(7, '0')};`));
    body.push(`            default: ${port} = 7'b1111111;`);
    body.push('        endcase');
    body.push('    end');
  }

  const mod = sanitizeName(moduleName, 'gate_design');
  const code = ['// Generated by the Logic Lab gate editor', `module ${mod} (`, ports.join(',\n'), ');', '', ...body, '', 'endmodule', ''].join('\n');
  return { code: code.replace(/\n{3,}/g, '\n\n'), notes };
}

export function toVerilog(c: Circuit, moduleName = 'gate_design'): string {
  return buildVerilog(c, moduleName, 'generic').code;
}

/**
 * Same design for the DE2 board: inputs on SW0.., buttons on KEY0.. (active
 * low), a clock on CLOCK_50, outputs on LEDR0.. and 7-segment displays on
 * HEX0...
 */
export function toDe2Verilog(c: Circuit, moduleName = 'gate_design'): string {
  const built = buildVerilog(c, `${sanitizeName(moduleName, 'gate_design')}_de2`, 'de2');
  return ['// DE2 board mapping:', ...built.notes, built.code].join('\n');
}

/* ── Blocks (sub-circuits) and tunnels ─────────────────────────────── */

/** A saved circuit that can be placed as a block (BLOCK node). */
export interface LibraryBlock {
  id: string;
  name: string;
  circuit: Circuit;
}
export type Library = Record<string, LibraryBlock>;

/** Pin names of a circuit used as a block: its inputs and outputs, top to bottom. */
export function blockPins(c: Circuit): { ins: string[]; outs: string[] } {
  const { ins, outs } = ioNodes(c);
  const name = (n: GateNode, i: number, p: string) => n.label.trim() || `${p}${i}`;
  return { ins: ins.map((n, i) => name(n, i, 'in')), outs: outs.map((n, i) => name(n, i, 'out')) };
}

/** Library blocks a circuit uses, directly or through other blocks. */
export function usedBlocks(c: Circuit, lib: Library, seen = new Set<string>()): Library {
  const out: Library = {};
  for (const n of c.nodes) {
    if (n.type !== 'BLOCK' || !n.ref || seen.has(n.ref) || !lib[n.ref]) continue;
    seen.add(n.ref);
    out[n.ref] = lib[n.ref];
    Object.assign(out, usedBlocks(lib[n.ref].circuit, lib, seen));
  }
  return out;
}

const MAX_DEPTH = 8;

/**
 * The circuit the simulator actually runs: every block (BLOCK) is replaced by
 * the parts inside it, and tunnels with the same name are joined. Top-level
 * node ids are kept, and a block's output k gets the signal key sig(block, k),
 * so values and traces line up with what the editor draws.
 */
export function flatten(c: Circuit, lib: Library = {}, depth = 0): Circuit {
  const nodes: GateNode[] = [];
  const inner: Wire[] = [];
  const inPins: Record<string, string[]> = {};
  for (const n of c.nodes) {
    if (n.type !== 'BLOCK') {
      nodes.push(n.type === 'TUNNEL' ? { ...n, type: 'BUF' } : n);
      continue;
    }
    const def = n.ref ? lib[n.ref] : undefined;
    inPins[n.id] = [];
    if (!def || depth >= MAX_DEPTH) continue;
    const body = flatten(def.circuit, lib, depth + 1);
    const { ins, outs } = ioNodes(def.circuit);
    const p = `${n.id}/`;
    const rename = new Map<string, string>();
    for (const m of body.nodes) {
      const k = outs.findIndex((o) => o.id === m.id);
      if (m.type === 'SEG7') continue;
      if (k >= 0) {
        rename.set(m.id, sig(n.id, k));
        nodes.push({ ...m, id: sig(n.id, k), type: 'BUF', label: '' });
      } else if (ins.some((x) => x.id === m.id)) {
        rename.set(m.id, p + m.id);
        nodes.push({ ...m, id: p + m.id, type: 'BUF', label: '' });
      } else {
        rename.set(m.id, p + m.id);
        nodes.push({ ...m, id: p + m.id });
      }
    }
    inPins[n.id] = ins.map((x) => p + x.id);
    for (const w of body.wires) {
      const from = rename.get(w.from);
      const to = rename.get(w.to);
      if (from && to) inner.push({ ...w, id: p + w.id, from, to });
    }
  }
  // Outer wires: into a block pin k -> its input buffer; from a block output k -> sig(block, k).
  const outer: Wire[] = [];
  for (const w of c.wires) {
    let next: Wire = w;
    if (inPins[w.to]) {
      const to = inPins[w.to][w.pin];
      if (!to) continue;
      next = { ...next, to, pin: 0 };
    }
    const fromNode = c.nodes.find((n) => n.id === w.from);
    if (fromNode?.type === 'BLOCK') {
      const { fromPin, ...rest } = next;
      next = { ...rest, from: sig(w.from, fromPin ?? 0) };
    }
    outer.push(next);
  }
  // Tunnels: a tunnel without an input reads the one with the same name that has one.
  const wires = [...inner, ...outer];
  const tunnels = c.nodes.filter((n) => n.type === 'TUNNEL');
  const driver = new Map<string, Wire>();
  for (const t of tunnels) {
    const w = wires.find((x) => x.to === t.id && x.pin === 0);
    const key = t.label.trim();
    if (w && key && !driver.has(key)) driver.set(key, w);
  }
  for (const t of tunnels) {
    const key = t.label.trim();
    const d = driver.get(key);
    if (!d || wires.some((x) => x.to === t.id && x.pin === 0)) continue;
    wires.push({ id: `${t.id}~tunnel`, from: d.from, ...(d.fromPin ? { fromPin: d.fromPin } : {}), to: t.id, pin: 0 });
  }
  return { nodes, wires };
}

/* ── Test cases (like Digital's "Test" component) ───────────────────── */

export interface TestCell {
  name: string;
  input: boolean;
  /** Written value: 0, 1, X (don't care) or C (clock pulse); hex digit for a 7-segment display. */
  want: string;
  got: string | null;
  ok: boolean;
}
export interface TestResult {
  error: string | null;
  rows: Array<{ line: number; ok: boolean; cells: TestCell[] }>;
  passed: number;
  failed: number;
}

/**
 * Runs a test table against the circuit. The first line names the signals
 * (inputs and outputs, by label, in any order); each further line gives one
 * value per signal. Inputs: 0, 1, a bus value (12, 0x1F, 0b101) or C (a
 * clock pulse 0 → 1 → 0 after the other inputs are applied). Outputs: a
 * value or X (not checked); a 7-segment display takes a hex digit. Rows run in order from reset, so sequential
 * circuits can be tested step by step. Lines starting with # are comments.
 */
export function runTests(c: Circuit, text: string): TestResult {
  const result: TestResult = { error: null, rows: [], passed: 0, failed: 0 };
  const lines = text.split('\n').map((l, i) => ({ line: i + 1, tokens: l.replace(/#.*$/, '').trim().split(/\s+/).filter((t) => t && t !== '|') }));
  const useful = lines.filter((l) => l.tokens.length);
  if (!useful.length) return { ...result, error: 'empty' };
  const [head, ...rows] = useful;
  const find = (name: string) =>
    c.nodes.find((n) => n.label === name && (SOURCES.includes(n.type) || SINKS.includes(n.type) || n.type === 'SEG7')) ??
    c.nodes.find((n) => n.label.toLowerCase() === name.toLowerCase() && (SOURCES.includes(n.type) || SINKS.includes(n.type) || n.type === 'SEG7'));
  const cols = head.tokens.map((name) => ({ name, node: find(name) }));
  const missing = cols.filter((col) => !col.node).map((col) => col.name);
  if (missing.length) return { ...result, error: `unknown:${missing.join(', ')}` };
  let seq: SeqState = EMPTY_SEQ;
  let inputs: Record<string, number> = {};
  for (const n of c.nodes) if (SOURCES.includes(n.type)) inputs[n.id] = 0;
  seq = settle(c, inputs, seq).seq;
  for (const row of rows) {
    if (row.tokens.length !== cols.length) return { ...result, error: `columns:${row.line}` };
    const pulses: string[] = [];
    const next = { ...inputs };
    cols.forEach((col, i) => {
      const n = col.node!;
      if (!SOURCES.includes(n.type)) return;
      const t = row.tokens[i].toUpperCase();
      if (t === 'C') {
        pulses.push(n.id);
        next[n.id] = 0;
      } else next[n.id] = (parseNumber(t) ?? 0) & maskOf(dataWidth(n));
    });
    let r = settle(c, next, seq);
    for (const pulse of [1, 0]) {
      if (!pulses.length) break;
      const p2 = { ...next };
      pulses.forEach((id) => { p2[id] = pulse; });
      r = settle(c, p2, r.seq);
    }
    inputs = next;
    seq = r.seq;
    const cells: TestCell[] = cols.map((col, i) => {
      const n = col.node!;
      const want = row.tokens[i].toUpperCase();
      if (SOURCES.includes(n.type)) return { name: col.name, input: true, want, got: null, ok: true };
      const v = r.ev.values[n.id] ?? 0;
      const got = n.type === 'SEG7' ? v.toString(16).toUpperCase() : String(v);
      // A 7-segment display is written as a hex digit; other outputs as a
      // number in decimal, 0x hex or 0b binary.
      const ok = want === 'X' || want === got || (n.type === 'SEG7' ? parseInt(want, 16) === v : parseNumber(want) === v);
      return { name: col.name, input: false, want, got, ok };
    });
    const ok = cells.every((cell) => cell.ok);
    result.rows.push({ line: row.line, ok, cells });
    if (ok) result.passed++;
    else result.failed++;
  }
  return result;
}

/** Reads 12, 0x1F, 0b101 (or a bare hex digit A–F); null when it is not a number. */
export function parseNumber(t: string): number | null {
  const x = t.trim().toLowerCase();
  if (/^0x[0-9a-f]+$/.test(x)) return parseInt(x.slice(2), 16);
  if (/^0b[01]+$/.test(x)) return parseInt(x.slice(2), 2);
  if (/^\d+$/.test(x)) return parseInt(x, 10);
  if (/^[a-f]$/.test(x)) return parseInt(x, 16);
  return null;
}

/** A starting table: every input combination (up to 6 inputs), outputs to fill in. */
export function testTemplate(c: Circuit): string {
  const { ins, outs, displays } = ioNodes(c);
  const names = (list: GateNode[]) => list.map((n, i) => n.label.trim() || `${n.type.toLowerCase()}${i}`);
  const inNames = names(ins);
  const outNames = [...names(outs), ...names(displays)];
  const lines = [`${inNames.join(' ')} | ${outNames.join(' ')}`];
  const widths = ins.map((n) => dataWidth(n));
  const total = widths.reduce((x, y) => x + y, 0);
  const count = total <= 6 ? 1 << total : 4;
  for (let combo = 0; combo < count; combo++) {
    let shift = total;
    const bits = ins.map((n, i) => {
      shift -= widths[i];
      return n.type === 'CLK' ? 'C' : String(total <= 6 ? (combo >> shift) & maskOf(widths[i]) : 0);
    });
    lines.push(`${bits.join(' ')} | ${outNames.map(() => 'X').join(' ')}`);
  }
  return lines.join('\n');
}

/* ── Presets ────────────────────────────────────────────────────────── */

const node = (id: string, type: GateType, x: number, y: number, label = '', delay = 1): GateNode => ({ id, type, x, y, label, delay });
const wire = (from: string, to: string, pin = 0, fromPin = 0): Wire => ({ id: `${from}-${fromPin}-${to}-${pin}`, from, to, pin, ...(fromPin ? { fromPin } : {}) });

export const PRESETS: Record<string, { title: { en: string; tr: string }; circuit: Circuit }> = {
  half_adder: {
    title: { en: 'Half adder', tr: 'Yarım toplayıcı' },
    circuit: {
      nodes: [node('a', 'IN', 60, 120, 'a'), node('b', 'IN', 60, 260, 'b'), node('x', 'XOR', 300, 110), node('n', 'AND', 300, 250), node('s', 'OUT', 540, 125, 'sum'), node('c', 'OUT', 540, 265, 'carry')],
      wires: [wire('a', 'x', 0), wire('b', 'x', 1), wire('a', 'n', 0), wire('b', 'n', 1), wire('x', 's'), wire('n', 'c')],
    },
  },
  mux2: {
    title: { en: '2:1 multiplexer', tr: '2:1 çoklayıcı' },
    circuit: {
      nodes: [node('a', 'IN', 40, 80, 'a'), node('s', 'IN', 40, 200, 'sel'), node('b', 'IN', 40, 320, 'b'), node('ns', 'NOT', 200, 150), node('g1', 'AND', 360, 90), node('g2', 'AND', 360, 290), node('o', 'OR', 540, 190), node('y', 'OUT', 720, 205, 'y')],
      wires: [wire('s', 'ns'), wire('a', 'g1', 0), wire('ns', 'g1', 1), wire('s', 'g2', 0), wire('b', 'g2', 1), wire('g1', 'o', 0), wire('g2', 'o', 1), wire('o', 'y')],
    },
  },
  hazard: {
    title: { en: 'Static hazard (glitch)', tr: 'Statik tehlike (glitch)' },
    circuit: {
      nodes: [node('a', 'IN', 40, 190, 'a'), node('b', 'IN', 40, 70, 'b'), node('c', 'IN', 40, 320, 'c'), node('na', 'NOT', 200, 250, '', 2), node('g1', 'AND', 380, 90), node('g2', 'AND', 380, 290), node('o', 'OR', 560, 190), node('y', 'OUT', 740, 205, 'y')],
      wires: [wire('b', 'g1', 0), wire('a', 'g1', 1), wire('a', 'na'), wire('na', 'g2', 0), wire('c', 'g2', 1), wire('g1', 'o', 0), wire('g2', 'o', 1), wire('o', 'y')],
    },
  },
  full_adder: {
    title: { en: 'Full adder from two half adders', tr: 'İki yarım toplayıcıdan tam toplayıcı' },
    circuit: {
      nodes: [node('a', 'IN', 40, 80, 'a'), node('b', 'IN', 40, 200, 'b'), node('ci', 'IN', 40, 340, 'cin'), node('h1', 'HA', 240, 100), node('h2', 'HA', 460, 180), node('o', 'OR', 680, 300), node('s', 'OUT', 900, 190, 'sum'), node('co', 'OUT', 900, 310, 'cout')],
      wires: [wire('a', 'h1', 0), wire('b', 'h1', 1), wire('h1', 'h2', 0), wire('ci', 'h2', 1), wire('h2', 's'), wire('h1', 'o', 0, 1), wire('h2', 'o', 1, 1), wire('o', 'co')],
    },
  },
  adder4: {
    title: { en: '4-bit adder → 7-segment', tr: '4 bit toplayıcı → 7 segment' },
    circuit: {
      nodes: [
        ...[0, 1, 2, 3].map((i) => node(`a${i}`, 'IN', 40, 20 + i * 64, `a${i}`)),
        ...[0, 1, 2, 3].map((i) => node(`b${i}`, 'IN', 40, 290 + i * 64, `b${i}`)),
        node('cin', 'CONST0', 180, 560),
        { ...node('add', 'ADD', 360, 150), bits: 4 },
        ...[0, 1, 2, 3].map((i) => node(`s${i}`, 'OUT', 620, 60 + i * 70, `s${i}`)),
        node('co', 'OUT', 620, 360, 'cout'),
        node('h', 'SEG7', 900, 150, 'hex0'),
      ],
      wires: [
        ...[0, 1, 2, 3].map((i) => wire(`a${i}`, 'add', i)),
        ...[0, 1, 2, 3].map((i) => wire(`b${i}`, 'add', 4 + i)),
        wire('cin', 'add', 8),
        ...[0, 1, 2, 3].map((i) => wire('add', `s${i}`, 0, i)),
        wire('add', 'co', 0, 4),
        ...[0, 1, 2, 3].map((i) => wire('add', 'h', i, i)),
      ],
    },
  },
  mux4: {
    title: { en: '4:1 multiplexer', tr: '4:1 çoklayıcı' },
    circuit: {
      nodes: [node('d0', 'IN', 40, 40, 'd0'), node('d1', 'IN', 40, 120, 'd1'), node('d2', 'IN', 40, 200, 'd2'), node('d3', 'IN', 40, 280, 'd3'), node('s0', 'IN', 40, 400, 's0'), node('s1', 'IN', 40, 480, 's1'), node('m', 'MUX4', 320, 180), node('y', 'OUT', 560, 235, 'y')],
      wires: [wire('d0', 'm', 0), wire('d1', 'm', 1), wire('d2', 'm', 2), wire('d3', 'm', 3), wire('s0', 'm', 4), wire('s1', 'm', 5), wire('m', 'y')],
    },
  },
  seg7: {
    title: { en: '7-segment display (4 switches)', tr: '7 segment gösterge (4 anahtar)' },
    circuit: {
      nodes: [node('b0', 'IN', 60, 60, 'b0'), node('b1', 'IN', 60, 150, 'b1'), node('b2', 'IN', 60, 240, 'b2'), node('b3', 'IN', 60, 330, 'b3'), node('h', 'SEG7', 360, 130, 'hex0')],
      wires: [wire('b0', 'h', 0), wire('b1', 'h', 1), wire('b2', 'h', 2), wire('b3', 'h', 3)],
    },
  },
  dff: {
    title: { en: 'D flip-flop', tr: 'D flip-flop' },
    circuit: {
      nodes: [node('d', 'IN', 60, 100, 'd'), node('clk', 'CLK', 60, 220, 'clk'), node('f', 'DFF', 300, 130), node('q', 'OUT', 540, 130, 'q')],
      wires: [wire('d', 'f', 0), wire('clk', 'f', 1), wire('f', 'q')],
    },
  },
  counter4: {
    title: { en: '4-bit ripple counter → 7-segment', tr: '4 bit dalgalı sayıcı → 7 segment' },
    circuit: {
      nodes: [
        node('one', 'CONST1', 60, 40), node('clk', 'CLK', 60, 200, 'clk'),
        node('t0', 'TFF', 240, 170), node('t1', 'TFF', 420, 170), node('t2', 'TFF', 600, 170), node('t3', 'TFF', 780, 170),
        node('q0', 'OUT', 260, 330, 'q0'), node('q1', 'OUT', 440, 330, 'q1'), node('q2', 'OUT', 620, 330, 'q2'), node('q3', 'OUT', 800, 330, 'q3'),
        node('h', 'SEG7', 960, 400, 'hex0'),
      ],
      wires: [
        wire('one', 't0', 0), wire('one', 't1', 0), wire('one', 't2', 0), wire('one', 't3', 0),
        wire('clk', 't0', 1), wire('t0', 't1', 1, 1), wire('t1', 't2', 1, 1), wire('t2', 't3', 1, 1),
        wire('t0', 'q0'), wire('t1', 'q1'), wire('t2', 'q2'), wire('t3', 'q3'),
        wire('t0', 'h', 0), wire('t1', 'h', 1), wire('t2', 'h', 2), wire('t3', 'h', 3),
      ],
    },
  },
  reg_counter: {
    title: { en: '4-bit register counter (buses)', tr: '4 bit yazmaçlı sayıcı (bus)' },
    circuit: {
      nodes: [
        node('clk', 'CLK', 40, 60, 'clk'),
        { ...node('r', 'REG', 200, 40), width: 4 },
        { ...node('sq', 'SPLIT', 360, 20), width: 4 },
        { ...node('k', 'CONST', 200, 250), width: 4, value: 1 },
        { ...node('sk', 'SPLIT', 360, 220), width: 4 },
        node('c0', 'CONST0', 360, 360),
        { ...node('add', 'ADD', 480, 60), bits: 4 },
        { ...node('m', 'MERGE', 680, 40), width: 4 },
        node('q', 'OUT', 820, 60, 'q'),
        node('h', 'SEG7', 840, 200, 'hex0'),
      ],
      wires: [
        wire('clk', 'r', 1), wire('m', 'r', 0), wire('r', 'sq'), wire('k', 'sk'),
        wire('sq', 'add', 0, 0), wire('sq', 'add', 1, 1), wire('sq', 'add', 2, 2), wire('sq', 'add', 3, 3),
        wire('sk', 'add', 4, 0), wire('sk', 'add', 5, 1), wire('sk', 'add', 6, 2), wire('sk', 'add', 7, 3), wire('c0', 'add', 8),
        wire('add', 'm', 0, 0), wire('add', 'm', 1, 1), wire('add', 'm', 2, 2), wire('add', 'm', 3, 3),
        wire('r', 'q'),
        wire('sq', 'h', 0, 0), wire('sq', 'h', 1, 1), wire('sq', 'h', 2, 2), wire('sq', 'h', 3, 3),
      ],
    },
  },
  ram: {
    title: { en: 'RAM 8 × 4: write with the button', tr: 'RAM 8 × 4: butonla yaz' },
    circuit: {
      nodes: [
        { ...node('a', 'IN', 40, 40, 'addr'), width: 3 },
        { ...node('d', 'IN', 40, 140, 'data'), width: 4 },
        node('we', 'IN', 40, 240, 'we'),
        node('wr', 'BTN', 40, 340, 'write'),
        { ...node('mem', 'RAM', 300, 150), width: 4, addrBits: 3 },
        node('q', 'OUT', 520, 170, 'q'),
      ],
      wires: [wire('a', 'mem', 0), wire('d', 'mem', 1), wire('we', 'mem', 2), wire('wr', 'mem', 3), wire('mem', 'q')],
    },
  },
};
