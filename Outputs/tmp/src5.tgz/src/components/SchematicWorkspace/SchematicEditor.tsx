import React, { useState } from 'react';
import Editor from '@monaco-editor/react';
import '../../lib/monacoSetup';
import { FileCode, X, Upload } from 'lucide-react';
import type { ProjectFile } from './SchematicProjectPanel';

import { useT } from '../../i18n/toolText';
interface SchematicEditorProps {
  files: ProjectFile[];
  activeFileIndex: number;
  onCodeChange: (value: string | undefined) => void;
  isDarkMode: boolean;
  onImportHDL: () => void;
  onClose?: () => void;
  isModified?: boolean;
}

export const SchematicEditor: React.FC<SchematicEditorProps> = ({
  files,
  activeFileIndex,
  onCodeChange,
  isDarkMode,
  onImportHDL,
  onClose,
  isModified,
}) => {
  const t = useT();
  const [isEditorReady, setIsEditorReady] = useState(false);
  const currentFile = files[activeFileIndex];

  return (
    <div
      data-testid="schematic-editor"
      data-editor-ready={isEditorReady ? 'true' : 'false'}
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'var(--bg-surface)',
        overflow: 'hidden',
      }}
    >
      {/* Editor Tab Bar */}
      <div
        style={{
          height: '34px',
          background: 'var(--bg-panel-header)',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 8px',
          userSelect: 'none',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '4px 10px',
              background: 'var(--bg-surface)',
              borderTop: '2px solid var(--accent-primary)',
              borderRight: '1px solid var(--border-subtle)',
              borderLeft: '1px solid var(--border-subtle)',
              borderRadius: '4px 4px 0 0',
              fontSize: '0.78rem',
              fontWeight: 600,
              color: 'var(--text-primary)',
            }}
          >
            <FileCode size={13} className="text-blue-500" />
            <span>{currentFile?.name || 'untitled.sv'}</span>
            {isModified && (
              <span
                title={t("File modified since last synthesis")}
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: '#f59e0b',
                }}
              />
            )}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <button
            data-testid="editor-import-hdl-btn"
            onClick={onImportHDL}
            className="hover:bg-[var(--bg-hover)] transition-colors"
            style={{
              padding: '3px 8px',
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              borderRadius: '4px',
              color: 'var(--text-secondary)',
              fontSize: '0.74rem',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
            }}
          >
            <Upload size={12} />
            <span>{t("Import HDL")}</span>
          </button>
          {onClose && (
            <button
              onClick={onClose}
              title={t("Close Editor")}
              className="p-1 rounded-[4px] hover:bg-[var(--bg-hover)] transition-colors"
              style={{
                background: 'transparent',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Monaco Container */}
      <div
        data-testid="schematic-monaco-editor"
        style={{ flex: 1, position: 'relative', overflow: 'hidden' }}
      >
        {currentFile ? (
          <Editor
            height="100%"
            language="systemverilog"
            theme={isDarkMode ? 'vs-dark' : 'vs-light'}
            value={currentFile.content}
            onChange={onCodeChange}
            loading={
              <div
                data-testid="monaco-loading"
                style={{
                  color: 'var(--text-secondary)',
                  padding: '16px',
                  fontFamily: 'sans-serif',
                  fontSize: '0.85rem',
                }}
              >
                Loading editor...
              </div>
            }
            onMount={(editor) => {
              setIsEditorReady(true);
              const ta = editor.getDomNode()?.querySelector('textarea');
              if (ta) {
                ta.setAttribute('data-testid', 'schematic-editor-textarea');
                ta.setAttribute('aria-label', 'HDL Code Editor');
              }
            }}
            options={{
              minimap: { enabled: false },
              fontSize: 13,
              wordWrap: 'on',
              lineNumbers: 'on',
              scrollBeyondLastLine: false,
              automaticLayout: true,
              tabSize: 2,
            }}
          />
        ) : (
          <div
            style={{
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px',
              color: 'var(--text-secondary)',
            }}
          >
            <div>{t("No HDL file open.")}</div>
            <button
              onClick={onImportHDL}
              style={{
                padding: '6px 14px',
                background: 'var(--accent-color)',
                color: '#fff',
                border: 'none',
                borderRadius: '6px',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              {t("Import HDL")}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
