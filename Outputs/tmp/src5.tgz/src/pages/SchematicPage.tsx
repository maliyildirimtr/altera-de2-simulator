import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { AlertCircle, FileCode, ImageDown } from 'lucide-react';
import { ShareButton } from '../components/Share/ShareButton';
import { useSharedProject } from '../services/useSharedProject';
import { downloadBlob, downloadText, svgToPngBlob } from '../utils/svgExport';
import { synthesizeVerilog, HdlSynthesisError, InternalSchematicError } from '../services/synthesizer';
import type { SynthesisProgress } from '../services/synthesizer';
import { loadWorkspace, restoreWorkspaceFlags, useWorkspaceAutosave } from '../services/workspaceStorage';
import { ResizableDivider } from '../components/DE2Workspace/ResizableDivider';
import { SchematicToolbar } from '../components/SchematicWorkspace/SchematicToolbar';
import type { SynthesisStatus, ViewMode } from '../components/SchematicWorkspace/SchematicToolbar';
import { SchematicProjectPanel } from '../components/SchematicWorkspace/SchematicProjectPanel';
import type { ProjectFile } from '../components/SchematicWorkspace/SchematicProjectPanel';
import { SchematicEditor } from '../components/SchematicWorkspace/SchematicEditor';
import { SchematicViewport } from '../components/SchematicWorkspace/SchematicViewport';
import type { SchematicViewportHandle } from '../components/SchematicWorkspace/SchematicViewport';
import { SchematicInspector } from '../components/SchematicWorkspace/SchematicInspector';
import type { SelectedItemInfo } from '../components/SchematicWorkspace/SchematicInspector';
import { SchematicConsole } from '../components/SchematicWorkspace/SchematicConsole';
import { consumePendingHandoff, peekPendingHandoff, markWorkspaceOrigin, markWorkspaceDirty, markWorkspaceUser } from '../services/exampleHandoff';
import { getExampleById } from '../examples/registry';
import '../index.css';

import { useT } from '../i18n/toolText';
const LAYOUT_STORAGE_KEY = 'schematic_workspace_layout_v1';

interface SchematicLayoutConfig {
  projectWidth: number;
  editorRatio: number;
  inspectorWidth: number;
  consoleHeight: number;
  isProjectOpen: boolean;
  isInspectorOpen: boolean;
  isConsoleOpen: boolean;
  viewMode: ViewMode;
  truthTableWidth: number;
}

const isDesktop = typeof window !== 'undefined' ? window.innerWidth >= 768 : true;
const isWideDesktop = typeof window !== 'undefined' ? window.innerWidth >= 1024 : true;

const DEFAULT_LAYOUT: SchematicLayoutConfig = {
  projectWidth: 240,
  editorRatio: 0.38,
  inspectorWidth: 260,
  consoleHeight: 180,
  isProjectOpen: isDesktop,
  isInspectorOpen: isWideDesktop,
  isConsoleOpen: false,
  viewMode: 'schematic',
  truthTableWidth: 340,
};

export default function SchematicPage({ isDarkMode }: { isDarkMode: boolean }) {
  const t = useT();
  // Layout persistence
  const [layout, setLayout] = useState<SchematicLayoutConfig>(() => {
    try {
      const saved = localStorage.getItem(LAYOUT_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_LAYOUT,
          ...parsed,
          viewMode: parsed.viewMode || 'schematic',
          truthTableWidth: typeof parsed.truthTableWidth === 'number' ? parsed.truthTableWidth : DEFAULT_LAYOUT.truthTableWidth,
        };
      }
    } catch (_) {}
    return DEFAULT_LAYOUT;
  });

  const saveLayout = useCallback((updates?: Partial<SchematicLayoutConfig>) => {
    setLayout((prev) => {
      const next = { ...prev, ...(updates || {}) };
      try {
        localStorage.setItem(LAYOUT_STORAGE_KEY, JSON.stringify(next));
      } catch (_) {}
      return next;
    });
  }, []);

  // Inspect initial handoff if present
  const initialHandoff = typeof window !== 'undefined' ? peekPendingHandoff() : null;
  const initialExample = initialHandoff && initialHandoff.targetTool === 'schematic' ? getExampleById(initialHandoff.exampleId) : null;

  // Autosaved project from a previous visit (ignored when an example is being opened)
  const [restored] = useState(() =>
    initialExample ? null : loadWorkspace<{ files: ProjectFile[]; activeFileIndex: number }>('schematic')
  );

  // Project files state - Fresh workspace starts clean with 0 files (Phase 12.2E)
  const [projectFiles, setProjectFiles] = useState<ProjectFile[]>(() => {
    if (initialExample) {
      consumePendingHandoff('schematic');
      markWorkspaceOrigin('schematic', 'example');
      return [{ name: initialExample.source.filename, content: initialExample.source.code }];
    }
    if (restored && Array.isArray(restored.data.files) && restored.data.files.length > 0) {
      restoreWorkspaceFlags('schematic', restored.origin, restored.dirty);
      return restored.data.files;
    }
    return [];
  });
  const [activeFileIndex, setActiveFileIndex] = useState(() => {
    const i = restored?.data.activeFileIndex ?? 0;
    return i >= 0 && i < projectFiles.length ? i : 0;
  });

  const schematicSave = useMemo(() => ({ files: projectFiles, activeFileIndex }), [projectFiles, activeFileIndex]);
  useWorkspaceAutosave(
    'schematic',
    schematicSave,
    projectFiles.length === 0
  );

  // Keep a ref to projectFiles for immediate access
  const projectFilesRef = useRef<ProjectFile[]>(projectFiles);
  projectFilesRef.current = projectFiles;

  // Synthesis settings
  const [optimizeInYosys, setOptimizeInYosys] = useState(false);
  const [simplifyDiagram, setSimplifyDiagram] = useState(true);

  // Synthesis & Circuit state
  const [circuitData, setCircuitData] = useState<any>(null);
  const [synthesisStatus, setSynthesisStatus] = useState<SynthesisStatus>(() =>
    projectFiles.length > 0 ? 'modified' : 'no_source'
  );
  const [topModule, setTopModule] = useState<string>(() => initialExample ? initialExample.topModule : '');
  const [lastSynthesizedContent, setLastSynthesizedContent] = useState<string>('');
  const [synthesisProgress, setSynthesisProgress] = useState<SynthesisProgress | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [errorKind, setErrorKind] = useState<'hdl' | 'internal' | null>(null);
  const [stdoutLog, setStdoutLog] = useState<string>('');
  const [stderrLog, setStderrLog] = useState<string>('');

  // Inspector selection state
  const [selectedItem, setSelectedItem] = useState<SelectedItemInfo | null>(null);

  // Viewport and File input refs
  const viewportRef = useRef<SchematicViewportHandle>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const centerWorkspaceRef = useRef<HTMLDivElement>(null);

  // Modal states
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [createPromptOpen, setCreatePromptOpen] = useState(false);
  const [createPromptValue, setCreatePromptValue] = useState('');

  // Open a project from a share link (#/schematic?p=…)
  useSharedProject(
    'schematic',
    () => projectFilesRef.current.some((f) => f.content.trim() !== ''),
    (payload) => {
      setProjectFiles(payload.files.map((f) => ({ name: f.name, content: f.content })));
      setActiveFileIndex(0);
      setCircuitData(null);
      setTopModule('');
      setLastSynthesizedContent('');
      setSynthesisStatus(payload.files.length > 0 ? 'modified' : 'no_source');
    },
    setAlertMessage
  );

  const exportSchematic = async (format: 'svg' | 'png') => {
    const svg = viewportRef.current?.exportSvg();
    if (!svg) {
      setAlertMessage('Synthesize the design first; there is no schematic to export yet.');
      return;
    }
    const base = (topModule || 'schematic').replace(/[^\w.-]+/g, '_');
    try {
      if (format === 'svg') downloadText(svg, `${base}.svg`, 'image/svg+xml');
      else downloadBlob(await svgToPngBlob(svg, 2), `${base}.png`);
    } catch (err) {
      setAlertMessage(`Export failed: ${(err as Error)?.message ?? 'unknown error'}`);
    }
  };

  // Synthesis handler
  const handleSynthesize = async () => {
    const currentFiles = projectFilesRef.current.length > 0 ? projectFilesRef.current : projectFiles;
    const hasCode = currentFiles.some((f) => f.content.trim() !== '');
    if (!hasCode) {
      setSynthesisStatus('no_source');
      setErrorMessage('Please enter HDL code or upload files to synthesize.');
      saveLayout({ isConsoleOpen: true });
      return;
    }

    setSynthesisStatus('synthesizing');
    setSynthesisProgress({ percent: 0, stage: 'Preparing' });
    setErrorMessage(null);
    setErrorKind(null);

    try {
      const result = await synthesizeVerilog(currentFiles, {
        optimize: optimizeInYosys,
        simplify: simplifyDiagram,
        onProgress: setSynthesisProgress,
      });

      setCircuitData(result);
      setTopModule(result._topModule || 'logic_test');
      setStdoutLog(result._stdout || '');
      setStderrLog(result._stderr || '');
      setLastSynthesizedContent(currentFiles[activeFileIndex]?.content || '');
      setSynthesisStatus('ready');
      setSelectedItem(null);
    } catch (err: any) {
      // Stale graph safety (Point 11 & 25): hide/invalidate graph and set status to Error
      setCircuitData(null);
      setTopModule('');
      setSynthesisStatus('error');
      const isInternal =
        err instanceof InternalSchematicError ||
        Boolean(err?.isInternalError) ||
        (!err?.isHdlError && !(err instanceof HdlSynthesisError) && (
          /is not a function|cannot read properties|cannot read property|undefined is not|typeerror/i.test(err?.message || '') ||
          /is not a function|cannot read properties|cannot read property|undefined is not|typeerror/i.test(err?.stack || '')
        ));
      const kind: 'hdl' | 'internal' = isInternal ? 'internal' : 'hdl';
      setErrorKind(kind);
      const errText = err?.message || 'Synthesis failed.';
      setErrorMessage(errText);
      setStderrLog(
        err?.stderr ||
          (isInternal
            ? `Internal Schematic Processing Error:\n${err?.message || ''}\n${err?.stack || ''}`
            : errText)
      );
      if (err?.stdout) setStdoutLog(err.stdout);
      setSelectedItem(null);
      // Automatically reveal Console/Problems panel on error
      saveLayout({ isConsoleOpen: true });
    }
  };

  // Focus Mode deliberate one-time Fit + Center (Point 1)
  const isFocusLayout =
    !layout.isProjectOpen &&
    !layout.isInspectorOpen &&
    !layout.isConsoleOpen &&
    layout.viewMode === 'schematic';
  const prevFocusRef = useRef(false);

  useEffect(() => {
    if (isFocusLayout && !prevFocusRef.current) {
      const timer = setTimeout(() => {
        viewportRef.current?.fit();
      }, 100);
      return () => clearTimeout(timer);
    }
    prevFocusRef.current = isFocusLayout;
  }, [isFocusLayout]);

  // Consume incoming example handoff (Phase 6)
  useEffect(() => {
    const handoff = consumePendingHandoff('schematic');
    if (handoff) {
      const ex = getExampleById(handoff.exampleId);
      if (ex) {
        setProjectFiles([{ name: ex.source.filename, content: ex.source.code }]);
        setActiveFileIndex(0);
        // Clear previous synthesis and circuit data so old graph cannot masquerade
        setCircuitData(null);
        setSynthesisStatus('modified');
        setTopModule(ex.topModule);
        setLastSynthesizedContent('');
        setErrorMessage(null);
        setErrorKind(null);
        setStdoutLog('');
        setStderrLog('');
        setSelectedItem(null);
        markWorkspaceOrigin('schematic', 'example');
      }
    }
  }, []);

  // Code editor change handler (Point 12: HDL change after success -> state = modified)
  const handleCodeChange = (value: string | undefined) => {
    const newContent = value || '';
    setProjectFiles((prev) => {
      const updated = [...prev];
      if (updated[activeFileIndex]) {
        if (updated[activeFileIndex].content !== newContent) {
          markWorkspaceDirty('schematic');
        }
        updated[activeFileIndex] = { ...updated[activeFileIndex], content: newContent };
      }
      return updated;
    });

    if (synthesisStatus === 'ready' && newContent !== lastSynthesizedContent) {
      setSynthesisStatus('modified');
    }
  };

  // File upload handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newFiles = [...projectFiles];
    let lastIndex = activeFileIndex;

    const readPromises = Array.from(files).map((file) => {
      return new Promise<void>((resolve) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          newFiles.push({ name: file.name, content: (event.target?.result as string) || '' });
          lastIndex = newFiles.length - 1;
          resolve();
        };
        reader.readAsText(file);
      });
    });

    await Promise.all(readPromises);
    setProjectFiles(newFiles);
    setActiveFileIndex(lastIndex);
    setSynthesisStatus('modified');
    markWorkspaceUser('schematic');

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Create new file
  const handleCreateNewFile = () => {
    setCreatePromptValue(`module${projectFiles.length + 1}.sv`);
    setCreatePromptOpen(true);
  };

  const submitCreateNewFile = (fileName: string) => {
    const name = fileName.trim() || `module${projectFiles.length + 1}.sv`;
    const cleanModuleName = name.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_]/g, '_');
    const templateContent = `module ${cleanModuleName}(\n    // Port declarations\n);\n\nendmodule\n`;
    const newFiles = [...projectFiles, { name, content: templateContent }];
    setProjectFiles(newFiles);
    setActiveFileIndex(newFiles.length - 1);
    setSynthesisStatus('modified');
    markWorkspaceDirty('schematic');
    setCreatePromptOpen(false);
    if (layout.viewMode === 'schematic') {
      saveLayout({ viewMode: 'split' });
    }
  };

  // Delete file
  const handleDeleteFile = (index: number) => {
    const newFiles = [...projectFiles];
    newFiles.splice(index, 1);
    setProjectFiles(newFiles);

    if (newFiles.length === 0) {
      setActiveFileIndex(0);
      setCircuitData(null);
      setSynthesisStatus('no_source');
      setTopModule('');
      setLastSynthesizedContent('');
    } else if (activeFileIndex === index) {
      setActiveFileIndex(Math.max(0, index - 1));
      setSynthesisStatus('modified');
    } else if (activeFileIndex > index) {
      setActiveFileIndex(activeFileIndex - 1);
      setSynthesisStatus('modified');
    } else {
      setSynthesisStatus('modified');
    }
    markWorkspaceDirty('schematic');
  };

  // Empty state action handlers
  const handleCreateModuleFromEmpty = () => {
    if (layout.viewMode === 'schematic') {
      saveLayout({ viewMode: 'split' });
    }
    handleCreateNewFile();
  };

  const handleBrowseExamples = () => {
    window.location.hash = '#/examples';
  };

  // Reset workspace layout to Phase 12.2E defaults
  const handleResetWorkspaceLayout = () => {
    const isDesk = typeof window !== 'undefined' ? window.innerWidth >= 768 : true;
    const isWideDesk = typeof window !== 'undefined' ? window.innerWidth >= 1024 : true;
    const freshDefaults: SchematicLayoutConfig = {
      ...DEFAULT_LAYOUT,
      isProjectOpen: isDesk,
      isInspectorOpen: isWideDesk,
    };
    setLayout(freshDefaults);
    try {
      localStorage.setItem(LAYOUT_STORAGE_KEY, JSON.stringify(freshDefaults));
    } catch (_) {}
  };

  // Resizing Editor <-> Schematic in Split View using ratio (Point 15)
  const handleEditorResize = (delta: number) => {
    if (!centerWorkspaceRef.current) return;
    const centerWidth = centerWorkspaceRef.current.clientWidth - (layout.isInspectorOpen ? layout.inspectorWidth : 0);
    if (centerWidth <= 100) return;

    const currentEditorPx = centerWidth * layout.editorRatio;
    const newPx = currentEditorPx + delta;
    const newRatio = Math.max(0.25, Math.min(0.75, newPx / centerWidth));
    setLayout((prev) => ({ ...prev, editorRatio: newRatio }));
  };

  // Determine visibility by view mode (Point 13)
  const showEditor = layout.viewMode === 'split' || layout.viewMode === 'code';
  const showSchematic = layout.viewMode === 'split' || layout.viewMode === 'schematic';

  // Calculate editor width percentage in Split View
  const editorWidthPercent = layout.viewMode === 'split' ? `${layout.editorRatio * 100}%` : '100%';

  // Adaptive Inspector collapse/restore for Truth Table (Point 6)
  const inspectorCollapsedByTruthTableRef = useRef(false);

  const handleTruthTableChange = (isOpen: boolean) => {
    if (isOpen) {
      if (layout.isInspectorOpen) {
        inspectorCollapsedByTruthTableRef.current = true;
        saveLayout({ isInspectorOpen: false });
      }
    } else {
      if (inspectorCollapsedByTruthTableRef.current) {
        inspectorCollapsedByTruthTableRef.current = false;
        saveLayout({ isInspectorOpen: true });
      }
    }
  };

  const handleToggleInspector = () => {
    inspectorCollapsedByTruthTableRef.current = false;
    saveLayout({ isInspectorOpen: !layout.isInspectorOpen });
  };

  return (
    <div
      data-testid="schematic-workspace"
      data-view-mode={layout.viewMode}
      data-compile-status={synthesisStatus}
      data-has-circuit={!!circuitData ? 'true' : 'false'}
      data-file-count={projectFiles.length}
      style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'var(--bg-app)',
        color: 'var(--text-primary)',
        overflow: 'hidden',
        userSelect: 'none',
      }}
    >
      {/* Hidden File Input for HDL Upload */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".v,.sv"
        onChange={handleFileUpload}
        style={{ display: 'none' }}
      />

      {/* Main Workspace Toolbar */}
      <SchematicToolbar
        status={synthesisStatus}
        progress={synthesisStatus === 'synthesizing' ? synthesisProgress : null}
        viewMode={layout.viewMode}
        onViewModeChange={(mode) => saveLayout({ viewMode: mode })}
        onSynthesize={handleSynthesize}
        onUploadClick={() => fileInputRef.current?.click()}
        actionsSlot={
          <>
            <ShareButton
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] text-xs font-medium border transition-colors shadow-xs"
              labelClassName="hidden 2xl:inline"
              getPayload={() => ({ v: 1, tool: 'schematic', files: projectFilesRef.current })}
              onMessage={(msg, kind) => { if (kind === 'error') setAlertMessage(msg); }}
            />
            {(['svg', 'png'] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                data-testid={`schematic-export-${fmt}`}
                onClick={() => exportSchematic(fmt)}
                disabled={!circuitData || synthesisStatus === 'error'}
                title={`Download the schematic as ${fmt.toUpperCase()}`}
                className="hidden xl:flex items-center gap-1.5 px-2 py-1 rounded-[4px] text-xs font-medium border transition-colors shadow-xs disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-subtle)', color: 'var(--text-primary)' }}
              >
                <ImageDown size={13} />
                <span className="hidden 2xl:inline">{fmt.toUpperCase()}</span>
              </button>
            ))}
          </>
        }
        onZoomIn={() => viewportRef.current?.zoomIn()}
        onZoomOut={() => viewportRef.current?.zoomOut()}
        onFit={() => viewportRef.current?.fit()}
        onResetView={() => viewportRef.current?.resetView()}
        isTruthTableOpen={viewportRef.current?.isTruthTableOpen || false}
        onToggleTruthTable={() => viewportRef.current?.toggleTruthTable()}
        isProjectOpen={layout.isProjectOpen}
        onToggleProject={() => saveLayout({ isProjectOpen: !layout.isProjectOpen })}
        isInspectorOpen={layout.isInspectorOpen}
        onToggleInspector={handleToggleInspector}
        isConsoleOpen={layout.isConsoleOpen}
        onToggleConsole={() => saveLayout({ isConsoleOpen: !layout.isConsoleOpen })}
        onResetLayout={handleResetWorkspaceLayout}
        errorCount={synthesisStatus === 'error' ? 1 : 0}
        hasCircuit={!!circuitData && synthesisStatus !== 'error'}
      />

      {/* Center Layout: Project Panel + Central Canvas / Editor + Inspector */}
      <div
        ref={centerWorkspaceRef}
        style={{
          display: 'flex',
          flex: 1,
          overflow: 'hidden',
          position: 'relative',
          width: '100%',
          height: '100%',
        }}
      >
        {/* 1. Project Panel */}
        {layout.isProjectOpen && (
          <div
            style={{
              width: `${layout.projectWidth}px`,
              height: '100%',
              flexShrink: 0,
              display: 'flex',
            }}
          >
            <SchematicProjectPanel
              files={projectFiles}
              activeFileIndex={activeFileIndex}
              onSelectFile={(idx) => setActiveFileIndex(idx)}
              onCreateFile={handleCreateNewFile}
              onDeleteFile={handleDeleteFile}
              optimizeInYosys={optimizeInYosys}
              onToggleOptimize={setOptimizeInYosys}
              simplifyDiagram={simplifyDiagram}
              onToggleSimplify={setSimplifyDiagram}
              topModule={topModule}
              synthesisStatus={synthesisStatus}
              onClose={() => saveLayout({ isProjectOpen: false })}
            />
          </div>
        )}

        {/* Divider 1: Project <-> Central Workspace */}
        {layout.isProjectOpen && (
          <ResizableDivider
            orientation="vertical"
            data-testid="divider-project-workspace"
            onResize={(delta) => {
              setLayout((prev) => ({
                ...prev,
                projectWidth: Math.max(180, Math.min(420, prev.projectWidth + delta)),
              }));
            }}
            onResizeEnd={() => saveLayout()}
            onReset={() => {
              setLayout((prev) => ({ ...prev, projectWidth: DEFAULT_LAYOUT.projectWidth }));
              saveLayout({ projectWidth: DEFAULT_LAYOUT.projectWidth });
            }}
          />
        )}

        {/* 2. Central Area (Editor + Schematic) & Bottom Console */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            flex: 1,
            minWidth: 0,
            height: '100%',
            overflow: 'hidden',
          }}
        >
          {/* Top: Editor and/or Schematic */}
          <div
            style={{
              display: 'flex',
              flex: 1,
              minHeight: 0,
              position: 'relative',
              overflow: 'hidden',
              width: '100%',
              height: '100%',
            }}
          >
            {/* Left/Main: HDL Monaco Editor */}
            {showEditor && (
              <div
                style={{
                  width: editorWidthPercent,
                  height: '100%',
                  flexShrink: 0,
                  display: 'flex',
                }}
              >
                <SchematicEditor
                  files={projectFiles}
                  activeFileIndex={activeFileIndex}
                  onCodeChange={handleCodeChange}
                  isDarkMode={isDarkMode}
                  onImportHDL={() => fileInputRef.current?.click()}
                  isModified={synthesisStatus === 'modified'}
                  onClose={
                    layout.viewMode === 'split'
                      ? () => saveLayout({ viewMode: 'schematic' })
                      : undefined
                  }
                />
              </div>
            )}

            {/* Divider 2: Editor <-> Schematic (in Split View) */}
            {layout.viewMode === 'split' && (
              <ResizableDivider
                orientation="vertical"
                data-testid="divider-editor-schematic"
                onResize={handleEditorResize}
                onResizeEnd={() => saveLayout()}
                onReset={() => {
                  setLayout((prev) => ({ ...prev, editorRatio: DEFAULT_LAYOUT.editorRatio }));
                  saveLayout({ editorRatio: DEFAULT_LAYOUT.editorRatio });
                }}
              />
            )}

            {/* Right/Main: DigitalJS Schematic Viewport */}
            {showSchematic && (
              <div
                style={{
                  flex: 1,
                  height: '100%',
                  minWidth: 0,
                  position: 'relative',
                  overflow: 'hidden',
                }}
              >
                <SchematicViewport
                  ref={viewportRef}
                  onAlert={setAlertMessage}
                  circuitData={circuitData}
                  simplify={simplifyDiagram}
                  status={synthesisStatus}
                  progress={synthesisStatus === 'synthesizing' ? synthesisProgress : null}
                  errorMessage={errorMessage}
                  errorKind={errorKind}
                  onRenderError={(renderErr: any) => {
                    setCircuitData(null);
                    setTopModule('');
                    setSynthesisStatus('error');
                    setErrorKind('internal');
                    const msg = renderErr?.message || 'Internal schematic rendering error.';
                    setErrorMessage(msg);
                    setStderrLog(`Internal Schematic Rendering Error:\n${msg}\n${renderErr?.stack || ''}`);
                    setSelectedItem(null);
                    saveLayout({ isConsoleOpen: true });
                  }}
                  onSelectItem={(item) => setSelectedItem(item)}
                  onOpenProblems={() => saveLayout({ isConsoleOpen: true })}
                  onImportHDL={() => fileInputRef.current?.click()}
                  onCreateModule={handleCreateModuleFromEmpty}
                  onBrowseExamples={handleBrowseExamples}
                  onSynthesize={handleSynthesize}
                  onTruthTableChange={handleTruthTableChange}
                  truthTableWidth={layout.truthTableWidth || 340}
                  onTruthTableResize={(w) => setLayout((prev) => ({ ...prev, truthTableWidth: w }))}
                  onTruthTableResizeEnd={() => saveLayout()}
                  isDarkMode={isDarkMode}
                  hasFiles={projectFiles.length > 0}
                />
              </div>
            )}
          </div>

          {/* Divider 4: Central Workspace <-> Console */}
          {layout.isConsoleOpen && (
            <ResizableDivider
              orientation="horizontal"
              data-testid="divider-workspace-console"
              onResize={(delta) => {
                setLayout((prev) => ({
                  ...prev,
                  consoleHeight: Math.max(100, Math.min(420, prev.consoleHeight - delta)),
                }));
              }}
              onResizeEnd={() => saveLayout()}
              onReset={() => {
                setLayout((prev) => ({ ...prev, consoleHeight: DEFAULT_LAYOUT.consoleHeight }));
                saveLayout({ consoleHeight: DEFAULT_LAYOUT.consoleHeight });
              }}
            />
          )}

          {/* Bottom: Console & Problems Panel */}
          {layout.isConsoleOpen && (
            <div
              style={{
                height: `${layout.consoleHeight}px`,
                flexShrink: 0,
                display: 'flex',
              }}
            >
              <SchematicConsole
                isOpen={layout.isConsoleOpen}
                onClose={() => saveLayout({ isConsoleOpen: false })}
                stdout={stdoutLog}
                stderr={stderrLog}
                error={errorMessage}
                onClear={() => {
                  setStdoutLog('');
                  setStderrLog('');
                  setErrorMessage(null);
                }}
              />
            </div>
          )}
        </div>

        {/* Divider 3: Central Workspace <-> Inspector */}
        {layout.isInspectorOpen && (
          <ResizableDivider
            orientation="vertical"
            data-testid="divider-workspace-inspector"
            onResize={(delta) => {
              setLayout((prev) => ({
                ...prev,
                inspectorWidth: Math.max(200, Math.min(450, prev.inspectorWidth - delta)),
              }));
            }}
            onResizeEnd={() => saveLayout()}
            onReset={() => {
              setLayout((prev) => ({ ...prev, inspectorWidth: DEFAULT_LAYOUT.inspectorWidth }));
              saveLayout({ inspectorWidth: DEFAULT_LAYOUT.inspectorWidth });
            }}
          />
        )}

        {/* 3. Inspector Panel */}
        {layout.isInspectorOpen && (
          <div
            style={{
              width: `${layout.inspectorWidth}px`,
              height: '100%',
              flexShrink: 0,
              display: 'flex',
            }}
          >
            <SchematicInspector
              selectedItem={selectedItem}
              circuitData={circuitData}
              topModule={topModule}
              synthesisStatus={synthesisStatus}
              onSetInputValue={(inputId, val) => {
                viewportRef.current?.setInput(inputId, val);
                if (selectedItem && selectedItem.id === inputId) {
                  setSelectedItem({ ...selectedItem, logicValue: val });
                }
              }}
              onClose={() => {
                inspectorCollapsedByTruthTableRef.current = false;
                saveLayout({ isInspectorOpen: false });
              }}
            />
          </div>
        )}
      </div>

      {/* Alert Modal */}
      {alertMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={() => setAlertMessage(null)}>
          <div
            className="relative flex flex-col w-full max-w-sm rounded-xl shadow-2xl overflow-hidden font-sans border"
            style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-strong)' }}
            onClick={e => e.stopPropagation()}
          >
            <div
              className="flex items-center gap-3 px-5 py-3.5 border-b"
              style={{ backgroundColor: 'var(--bg-panel-header)', borderColor: 'var(--border-subtle)' }}
            >
              <div className="p-1.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-amber-500">
                <AlertCircle className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{t("Action Blocked")}</h3>
            </div>
            <div className="p-5 text-xs" style={{ color: 'var(--text-secondary)' }}>
              {alertMessage}
            </div>
            <div
              className="flex justify-end px-5 py-3 border-t"
              style={{ backgroundColor: 'var(--bg-panel-header)', borderColor: 'var(--border-subtle)' }}
            >
              <button
                onClick={() => setAlertMessage(null)}
                className="px-3 py-1.5 text-xs font-medium rounded-md border transition-colors hover:bg-[var(--bg-hover)]"
                style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-subtle)', color: 'var(--text-primary)' }}
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Prompt Modal */}
      {createPromptOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={() => setCreatePromptOpen(false)}>
          <div
            className="relative flex flex-col w-full max-w-sm rounded-xl shadow-2xl overflow-hidden font-sans border"
            style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-strong)' }}
            onClick={e => e.stopPropagation()}
          >
            <div
              className="flex items-center gap-3 px-5 py-3.5 border-b"
              style={{ backgroundColor: 'var(--bg-panel-header)', borderColor: 'var(--border-subtle)' }}
            >
              <div className="p-1.5 rounded-md bg-blue-500/10 border border-blue-500/20 text-blue-500">
                <FileCode className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>{t("Create New Module")}</h3>
            </div>
            <div className="p-5">
              <label className="block text-xs font-medium mb-2" style={{ color: 'var(--text-secondary)' }}>{t("Enter HDL module file name:")}</label>
              <input
                type="text"
                value={createPromptValue}
                onChange={e => setCreatePromptValue(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') submitCreateNewFile(createPromptValue);
                  if (e.key === 'Escape') setCreatePromptOpen(false);
                }}
                className="w-full px-3 py-2 text-xs rounded-md border focus:outline-none transition-colors"
                style={{
                  backgroundColor: 'var(--bg-app)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-primary)',
                }}
                autoFocus
              />
            </div>
            <div
              className="flex justify-end gap-2 px-5 py-3 border-t"
              style={{ backgroundColor: 'var(--bg-panel-header)', borderColor: 'var(--border-subtle)' }}
            >
              <button
                onClick={() => setCreatePromptOpen(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-md border transition-colors hover:bg-[var(--bg-hover)]"
                style={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-subtle)', color: 'var(--text-secondary)' }}
              >
                Cancel
              </button>
              <button
                onClick={() => submitCreateNewFile(createPromptValue)}
                className="px-3 py-1.5 text-xs font-medium rounded-md transition-colors"
                style={{ backgroundColor: 'var(--accent-primary)', color: '#ffffff' }}
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
