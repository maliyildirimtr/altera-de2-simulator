import { Cpu } from 'lucide-react';
import { useState, useCallback, useEffect, useMemo, useRef } from 'react';
import { useBoardStore } from '../store/boardStore';
import { compileVerilog } from '../core/simulator/verilogEngine';
import { autoMapPort, type ParsedPort } from '../utils/parser/pinParser';

import { DE2Toolbar } from '../components/DE2Workspace/DE2Toolbar';
import { ProjectPanel } from '../components/DE2Workspace/ProjectPanel';
import { BoardViewport } from '../components/DE2Workspace/BoardViewport';
import { InspectorPanel } from '../components/DE2Workspace/InspectorPanel';
import { ConsolePanel, type ConsoleMessage } from '../components/DE2Workspace/ConsolePanel';
import { ImportDialog } from '../components/DE2Workspace/ImportDialog';
import { CodeEditor } from '../components/Editor/CodeEditor';
import { lintVerilog, publishDiagnostics } from '../core/simulator/diagnostics';
import { buildQuartusProject } from '../utils/quartusProject';
import { createZip } from '../utils/zip';
import { downloadBlob } from '../utils/svgExport';
import { ResizableDivider } from '../components/DE2Workspace/ResizableDivider';
import { consumePendingHandoff, markWorkspaceOrigin, peekPendingHandoff } from '../services/exampleHandoff';
import { loadWorkspace, restoreWorkspaceFlags, useWorkspaceAutosave } from '../services/workspaceStorage';
import { ShareButton } from '../components/Share/ShareButton';
import { OpenInSchematicButton } from '../components/Share/OpenInToolButton';
import { useSharedProject } from '../services/useSharedProject';
import { EXAMPLES_LIST, getExampleById } from '../examples/registry';

const STORAGE_KEY = 'de2_workspace_layout_v1';

export type DE2ViewMode = 'board' | 'split' | 'code';

interface WorkspaceLayout {
  projectWidth: number;
  inspectorWidth: number;
  editorRatio: number;
  consoleHeight: number;
  pinMappingHeight: number;
  activeView: DE2ViewMode;
}

const DEFAULT_LAYOUT: WorkspaceLayout = {
  projectWidth: 220,
  inspectorWidth: 300,
  editorRatio: 0.38,
  consoleHeight: 190,
  pinMappingHeight: 220,
  activeView: 'board',
};

function loadSavedLayout(): WorkspaceLayout {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_LAYOUT;
    const parsed = JSON.parse(raw);
    return {
      projectWidth: typeof parsed.projectWidth === 'number' && parsed.projectWidth >= 170 && parsed.projectWidth <= 360
        ? parsed.projectWidth : DEFAULT_LAYOUT.projectWidth,
      inspectorWidth: typeof parsed.inspectorWidth === 'number' && parsed.inspectorWidth >= 240 && parsed.inspectorWidth <= 450
        ? parsed.inspectorWidth : DEFAULT_LAYOUT.inspectorWidth,
      editorRatio: typeof parsed.editorRatio === 'number' && parsed.editorRatio >= 0.25 && parsed.editorRatio <= 0.68
        ? parsed.editorRatio : DEFAULT_LAYOUT.editorRatio,
      consoleHeight: typeof parsed.consoleHeight === 'number' && parsed.consoleHeight >= 100 && parsed.consoleHeight <= 450
        ? parsed.consoleHeight : DEFAULT_LAYOUT.consoleHeight,
      pinMappingHeight: typeof parsed.pinMappingHeight === 'number' && parsed.pinMappingHeight >= 120 && parsed.pinMappingHeight <= 480
        ? parsed.pinMappingHeight : DEFAULT_LAYOUT.pinMappingHeight,
      activeView: (parsed.activeView === 'board' || parsed.activeView === 'split' || parsed.activeView === 'code')
        ? parsed.activeView
        : 'board',
    };
  } catch {
    return DEFAULT_LAYOUT;
  }
}

export default function DE2Simulator({ isDarkMode = true }: { isDarkMode?: boolean }) {
  const {
    hdlCode,
    setHdlCode,
    setEngine,
    compileState,
    markCompileFailed,
    pinMappings,
    setPinMappings,
    resetBoard,
    runSimulationCycle,
    stopAutoSimulation,
    isUploaderOpen,
    setUploaderOpen,
  } = useBoardStore();

  // Persistent panel dimensions & ratio state
  const [layout, setLayout] = useState<WorkspaceLayout>(loadSavedLayout);
  const centerRef = useRef<HTMLElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);

  // Layout UI state - Default to board mode in fresh workspace
  const [activeView, setActiveView] = useState<DE2ViewMode>(() => layout.activeView || 'board');
  const [isProjectOpen, setIsProjectOpen] = useState(true);
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);

  const persistLayout = useCallback((updates?: Partial<WorkspaceLayout>) => {
    setLayout(prev => {
      const next = { ...prev, ...updates };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch (_) {}
      return next;
    });
  }, []);

  const handleSelectView = useCallback((view: DE2ViewMode) => {
    setActiveView(view);
    persistLayout({ activeView: view });
  }, [persistLayout]);

  const handleResetWorkspaceLayout = useCallback(() => {
    setLayout(DEFAULT_LAYOUT);
    setActiveView(DEFAULT_LAYOUT.activeView);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_LAYOUT));
    } catch (_) {}
  }, []);

  // Responsive: collapse side panels on mobile/tablet viewports (<= 768px)
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setIsProjectOpen(false);
        setIsInspectorOpen(false);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Compiler / Console state
  const [isCompiling, setIsCompiling] = useState(false);
  const [compileError, setCompileError] = useState<string | null>(null);
  const [compiledSource, setCompiledSource] = useState('');
  const [consoleMessages, setConsoleMessages] = useState<ConsoleMessage[]>([
    {
      id: 'init',
      type: 'info',
      text: 'DE2 Simulator ready. Load or write HDL, then Compile.',
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const addLog = useCallback((type: ConsoleMessage['type'], text: string) => {
    setConsoleMessages(prev => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random()}`,
        type,
        text,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  }, []);

  // Restore the autosaved project after a refresh. The board store outlives
  // route changes, so this only applies when it is empty and no example is
  // being opened.
  useEffect(() => {
    if (peekPendingHandoff()?.targetTool === 'de2') return;
    if (useBoardStore.getState().hdlCode.trim()) return;
    const saved = loadWorkspace<{ hdlCode: string; pinMappings: ParsedPort[] }>('de2');
    if (!saved || !saved.data.hdlCode?.trim()) return;
    restoreWorkspaceFlags('de2', saved.origin, saved.dirty);
    // An unedited example is restored from the current bundle, not from the
    // saved copy, so a site update (e.g. new example text) is not masked by
    // an old autosave.
    let code = saved.data.hdlCode;
    if (saved.origin === 'example' && !saved.dirty) {
      const top = /\bmodule\s+(\w+)/.exec(code)?.[1];
      const current = EXAMPLES_LIST.find((ex) => ex.de2?.supported && ex.de2.topModule === top)?.de2?.source;
      if (current) code = current;
    }
    setHdlCode(code);
    setPinMappings(Array.isArray(saved.data.pinMappings) ? saved.data.pinMappings : []);
    addLog('info', 'Restored your last DE2 project. Compile to run it.');
  }, [setHdlCode, setPinMappings, addLog]);

  const de2Save = useMemo(() => ({ hdlCode, pinMappings }), [hdlCode, pinMappings]);
  useWorkspaceAutosave('de2', de2Save, !hdlCode.trim());

  // Open a project from a share link (#/de2-simulator?p=…)
  useSharedProject(
    'de2',
    () => !!useBoardStore.getState().hdlCode.trim(),
    (payload) => {
      const code = payload.files.map((f) => f.content).join('\n\n');
      setHdlCode(code);
      setPinMappings(Array.isArray(payload.pinMappings) ? (payload.pinMappings as ParsedPort[]) : []);
      setEngine(null);
      setCompileError(null);
      resetBoard();
      addLog('info', 'Opened a shared DE2 project. Compile to run it.');
    },
    (msg) => addLog('error', msg)
  );

  // Consume incoming example handoff (Phase 6)
  useEffect(() => {
    const handoff = consumePendingHandoff('de2');
    if (handoff) {
      const ex = getExampleById(handoff.exampleId);
      if (ex && ex.de2) {
        setHdlCode(ex.de2.source);
        setPinMappings([]);
        // Re-use existing boardStore state setters (engine invalidation + board reset)
        setEngine(null);
        setCompileError(null);
        resetBoard();
        addLog('info', `Loaded example into DE2: ${ex.title} (${ex.de2.filename})`);
        markWorkspaceOrigin('de2', 'example');
        // Example handoff defaults to Board mode
        setActiveView('board');
        persistLayout({ activeView: 'board' });
      }
    }
  }, [setHdlCode, setPinMappings, setEngine, resetBoard, addLog, persistLayout]);

  /** Simulator → real board: a ready-to-compile Quartus II project as a .zip. */
  const handleExportQuartus = useCallback(() => {
    const st = useBoardStore.getState();
    if (!st.hdlCode.trim()) {
      addLog('warn', 'Nothing to export: write or open a design first.');
      return;
    }
    let module;
    try {
      module = compileVerilog(st.hdlCode);
    } catch (err: any) {
      addLog('error', `Export failed: ${err?.message || 'the design could not be read.'}`);
      return;
    }
    const top = module.topModule || 'top';
    const project = buildQuartusProject({
      topModule: top,
      source: st.hdlCode,
      mappings: st.pinMappings,
      portWidths: module.portWidths ?? {},
    });
    downloadBlob(createZip(project.files.map((f) => ({ name: `${top}/${f.name}`, content: f.content }))), `${top}_quartus.zip`);
    addLog('success', `Quartus project exported: ${top}_quartus.zip (${project.pinCount} pins, Cyclone II EP2C35F672C6). Open ${top}.qpf in Quartus II 13.0 SP1.`);
    if (project.unresolved.length) {
      addLog('warn', `No DE2 pin for: ${project.unresolved.join(', ')}. Map them in Pin Mapping or add them in Quartus.`);
    }
  }, [addLog]);

  // Exact existing compilation engine flow
  const handleCompile = useCallback(() => {
    if (!hdlCode || hdlCode.trim().length === 0) {
      addLog('warn', 'Compilation skipped: No HDL source code to compile.');
      return;
    }

    stopAutoSimulation();
    setIsCompiling(true);
    try {
      const module = compileVerilog(hdlCode);
      const diagnostics = lintVerilog(hdlCode, module.transpileError);
      publishDiagnostics(diagnostics);
      for (const dgn of diagnostics) {
        addLog(dgn.severity === 'error' ? 'error' : 'warn', `Line ${dgn.line}: ${dgn.message.en}`);
      }
      setEngine(module);
      setCompiledSource(hdlCode);
      setCompileError(null);
      if (module.transpileError && diagnostics.length === 0) {
        // The ports were read but part of the logic uses a construct the
        // built-in simulator cannot run; outputs will not change.
        addLog('warn', `Some logic could not be simulated and is ignored: ${module.transpileError}`);
      }

      // Auto-assign ports to virtual board components if not already mapped
      if (pinMappings.length === 0 && (module.inputs.length > 0 || module.outputs.length > 0)) {
        const autoPins: ParsedPort[] = [];
        const allPorts = [...module.inputs, ...module.outputs];
        for (const port of allPorts) {
          const guessed = autoMapPort(port);
          autoPins.push({
            portName: port,
            physicalPin: null,
            virtualComponent: guessed || '',
          });
        }
        if (autoPins.length > 0) {
          setPinMappings(autoPins);
          addLog('info', `Auto-detected ${autoPins.length} ports from top module.`);
        }
      }

      // Compile only prepares the design. The board stays idle — no outputs,
      // no reaction to switches — until the user presses Run (or Step Clk).
      const modName = module.topModule || 'top';
      addLog(
        'success',
        `Compiled "${modName}" successfully (${module.inputs.length} inputs, ${module.outputs.length} outputs). Press Run to start.`
      );
    } catch (err: any) {
      const rawError = err.message || 'Unknown compilation syntax error.';
      const diagnostics = lintVerilog(hdlCode);
      publishDiagnostics(diagnostics);
      const firstError = diagnostics.find((dgn) => dgn.severity === 'error');
      markCompileFailed();
      setCompileError(firstError ? `Line ${firstError.line}: ${firstError.message.en}` : rawError);
      addLog('error', `Compilation failed: ${firstError ? `line ${firstError.line}: ${firstError.message.en}` : rawError}`);
      for (const dgn of diagnostics.filter((x) => x !== firstError)) {
        addLog(dgn.severity === 'error' ? 'error' : 'warn', `Line ${dgn.line}: ${dgn.message.en}`);
      }
      setIsConsoleOpen(true);
    } finally {
      setIsCompiling(false);
    }
  }, [hdlCode, pinMappings, setEngine, setPinMappings, runSimulationCycle, stopAutoSimulation, markCompileFailed, addLog]);

  return (
    <div
      data-testid="de2-workspace"
      data-compile-status={isCompiling ? 'compiling' : compileState}
      className="flex-1 flex flex-col h-full w-full overflow-hidden font-sans"
      style={{
        backgroundColor: 'var(--bg-app)',
        color: 'var(--text-primary)',
      }}
    >
      {/* ── Top Toolbar ── */}
      <DE2Toolbar
        activeView={activeView}
        onSelectView={handleSelectView}
        onOpenImport={() => setUploaderOpen(true)}
        actionsSlot={
          <>
          <OpenInSchematicButton
            className="flex items-center gap-1.5 px-2.5 h-[30px] rounded-[4px] border font-medium transition-colors text-xs"
            getFiles={() => [{ name: 'main.sv', content: useBoardStore.getState().hdlCode }]}
            onError={(msg) => addLog('error', msg)}
          />
          <button
            type="button"
            data-testid="de2-export-quartus"
            onClick={handleExportQuartus}
            className="flex items-center gap-1.5 px-2.5 h-[30px] rounded-[4px] border font-medium transition-colors text-xs"
            style={{ borderColor: 'var(--border-subtle)', color: 'var(--text-primary)', backgroundColor: 'var(--bg-surface)' }}
            title="Download a Quartus II project (.qpf/.qsf/.sdc + source) for the real DE2 board"
          >
            <Cpu size={13} />
            <span className="hidden xl:inline">Quartus</span>
          </button>
          <ShareButton
            className="flex items-center gap-1.5 px-2.5 h-[30px] rounded-[4px] border font-medium transition-colors text-xs"
            labelClassName="hidden xl:inline"
            getPayload={() => {
              const st = useBoardStore.getState();
              return { v: 1, tool: 'de2', files: [{ name: 'main.sv', content: st.hdlCode }], pinMappings: st.pinMappings };
            }}
            onMessage={(msg, kind) => addLog(kind === 'error' ? 'error' : 'info', msg)}
          />
          </>
        }
        onCompile={handleCompile}
        isCompiling={isCompiling}
        projectPanelOpen={isProjectOpen}
        onToggleProjectPanel={() => setIsProjectOpen(prev => !prev)}
        inspectorOpen={isInspectorOpen}
        onToggleInspector={() => setIsInspectorOpen(prev => !prev)}
        consoleOpen={isConsoleOpen}
        onToggleConsole={() => setIsConsoleOpen(prev => !prev)}
        onResetLayout={handleResetWorkspaceLayout}
      />

      {/* ── Main Workspace Body ── */}
      <div ref={bodyRef} className="flex-1 flex flex-row overflow-hidden relative min-h-0">
        {/* Left: Project Panel */}
        <ProjectPanel
          isOpen={isProjectOpen}
          width={layout.projectWidth}
          onToggle={() => setIsProjectOpen(false)}
          onOpenImport={() => setUploaderOpen(true)}
          activeView={activeView}
          onSelectFile={() => {
            if (activeView === 'board') handleSelectView('split');
          }}
        />

        {/* Project Panel Splitter (hidden when collapsed) */}
        {isProjectOpen && (
          <ResizableDivider
            orientation="vertical"
            data-testid="splitter-project"
            aria-label="Resize Project Panel"
            valueMin={170}
            valueMax={360}
            valueNow={layout.projectWidth}
            onResize={(delta) => {
              setLayout(prev => ({
                ...prev,
                projectWidth: Math.min(360, Math.max(170, prev.projectWidth + delta)),
              }));
            }}
            onResizeEnd={() => persistLayout()}
            onReset={() => {
              setLayout(prev => ({ ...prev, projectWidth: DEFAULT_LAYOUT.projectWidth }));
              persistLayout({ projectWidth: DEFAULT_LAYOUT.projectWidth });
            }}
          />
        )}

        {/* Center: Dynamic Workspace (Board / Split / Code) */}
        <main ref={centerRef} className="flex-1 flex flex-row overflow-hidden min-w-0 relative">
          {/* Split View: Left column is Code Editor with dynamic ratio */}
          {activeView === 'split' && (
            <>
              <div
                style={{ width: `${Math.round(layout.editorRatio * 10000) / 100}%` }}
                className="h-full flex flex-col shrink-0 overflow-hidden"
              >
                <CodeEditor isOpen={true} onOpenImport={() => setUploaderOpen(true)} isDarkMode={isDarkMode} />
              </div>

              {/* Editor ↔ Board Divider (Zero physical dead space) */}
              <ResizableDivider
                orientation="vertical"
                data-testid="splitter-editor-board"
                aria-label="Resize HDL Editor and Board Viewport"
                valueMin={25}
                valueMax={68}
                valueNow={Math.round(layout.editorRatio * 100)}
                onResize={(delta, _pos, ratioStep) => {
                  if (ratioStep !== undefined) {
                    setLayout(prev => ({
                      ...prev,
                      editorRatio: Math.min(0.68, Math.max(0.25, +(prev.editorRatio + ratioStep).toFixed(3))),
                    }));
                    return;
                  }
                  const totalW = centerRef.current?.clientWidth || 800;
                  if (totalW <= 0) return;
                  setLayout(prev => {
                    const currentPx = totalW * prev.editorRatio;
                    const targetPx = currentPx + delta;
                    const minRatio = Math.max(0.25, 260 / totalW);
                    const maxRatio = Math.min(0.68, (totalW - 350) / totalW);
                    const clamped = Math.min(maxRatio, Math.max(minRatio, targetPx / totalW));
                    return { ...prev, editorRatio: +clamped.toFixed(4) };
                  });
                }}
                onResizeEnd={() => persistLayout()}
                onReset={() => {
                  setLayout(prev => ({ ...prev, editorRatio: DEFAULT_LAYOUT.editorRatio }));
                  persistLayout({ editorRatio: DEFAULT_LAYOUT.editorRatio });
                }}
              />
            </>
          )}

          {/* Full Code View */}
          {activeView === 'code' && (
            <div className="flex-1 h-full flex flex-col min-w-0">
              <CodeEditor isOpen={true} onOpenImport={() => setUploaderOpen(true)} isDarkMode={isDarkMode} />
            </div>
          )}

          {/* Board Viewport (Rendered in 'board' and 'split' modes) */}
          {(activeView === 'board' || activeView === 'split') && (
            <div className="flex-1 h-full flex flex-col min-w-0 overflow-hidden relative">
              <BoardViewport isSplitView={activeView === 'split'} />
            </div>
          )}
        </main>

        {/* Inspector Panel Splitter (hidden when collapsed) */}
        {isInspectorOpen && (
          <ResizableDivider
            orientation="vertical"
            data-testid="splitter-inspector"
            aria-label="Resize Inspector Panel"
            valueMin={240}
            valueMax={450}
            valueNow={layout.inspectorWidth}
            onResize={(delta) => {
              // Dragging left (negative delta) increases inspector width
              setLayout(prev => ({
                ...prev,
                inspectorWidth: Math.min(450, Math.max(240, prev.inspectorWidth - delta)),
              }));
            }}
            onResizeEnd={() => persistLayout()}
            onReset={() => {
              setLayout(prev => ({ ...prev, inspectorWidth: DEFAULT_LAYOUT.inspectorWidth }));
              persistLayout({ inspectorWidth: DEFAULT_LAYOUT.inspectorWidth });
            }}
          />
        )}

        {/* Right: Inspector Panel */}
        <InspectorPanel
          isOpen={isInspectorOpen}
          width={layout.inspectorWidth}
          pinMappingHeight={layout.pinMappingHeight}
          onPinMappingResize={(delta) => {
            setLayout(prev => ({
              ...prev,
              pinMappingHeight: Math.min(480, Math.max(120, prev.pinMappingHeight + delta)),
            }));
          }}
          onPinMappingReset={() => {
            setLayout(prev => ({ ...prev, pinMappingHeight: DEFAULT_LAYOUT.pinMappingHeight }));
            persistLayout({ pinMappingHeight: DEFAULT_LAYOUT.pinMappingHeight });
          }}
          onPinMappingResizeEnd={() => persistLayout()}
          onToggle={() => setIsInspectorOpen(false)}
        />
      </div>

      {/* ── Console Splitter (Top of Console, hidden when collapsed) ── */}
      {isConsoleOpen && (
        <ResizableDivider
          orientation="horizontal"
          data-testid="splitter-console"
          aria-label="Resize Console Panel"
          valueMin={100}
          valueMax={Math.max(220, Math.floor((bodyRef.current?.clientHeight || 600) * 0.45))}
          valueNow={layout.consoleHeight}
          onResize={(delta) => {
            setLayout(prev => {
              const totalBody = (bodyRef.current?.clientHeight || 500) + (isConsoleOpen ? prev.consoleHeight : 0);
              const maxH = Math.max(280, Math.floor(totalBody * 0.45));
              return {
                ...prev,
                consoleHeight: Math.min(maxH, Math.max(100, prev.consoleHeight - delta)),
              };
            });
          }}
          onResizeEnd={() => persistLayout()}
          onReset={() => {
            setLayout(prev => ({ ...prev, consoleHeight: DEFAULT_LAYOUT.consoleHeight }));
            persistLayout({ consoleHeight: DEFAULT_LAYOUT.consoleHeight });
          }}
        />
      )}

      {/* ── Bottom: Console & Problems Panel ── */}
      <ConsolePanel
        isOpen={isConsoleOpen}
        height={layout.consoleHeight}
        onToggle={() => setIsConsoleOpen(prev => !prev)}
        messages={consoleMessages}
        compileError={compileError}
        onClear={() => setConsoleMessages([])}
        compiledSource={compiledSource}
      />

      {/* ── File Import Dialog ── */}
      <ImportDialog
        isOpen={isUploaderOpen}
        onClose={() => setUploaderOpen(false)}
        onImportSuccess={summary => {
          addLog('info', summary);
          // Auto-compile when new HDL file is loaded
          setTimeout(handleCompile, 100);
        }}
      />
    </div>
  );
}
