import React from 'react';
import {
  Play, RotateCcw, ZoomIn, ZoomOut, Maximize2, Settings,
  FolderOpen, FileCode, Terminal, Layers, Activity, Columns,
} from 'lucide-react';
import type { VCDTimescale } from '../../services/vcdParser';
import { formatTime } from '../../services/waveformRenderer';

import { useT } from '../../i18n/toolText';
export interface WaveformToolbarProps {
  fileName?: string | null;
  isCompiled: boolean;
  isCompiling: boolean;
  isSimRunning: boolean;
  isPlaying?: boolean;
  zoomLevel: number;
  currentTime: number;
  cursorB: number | null;
  timescale: VCDTimescale | undefined;
  projectPanelOpen: boolean;
  objectsPanelOpen: boolean;
  editorOpen?: boolean;
  consoleOpen: boolean;
  mainView: 'waveform' | 'editor' | 'split';
  onChangeMainView: (view: 'waveform' | 'editor' | 'split') => void;
  onToggleProjectPanel: () => void;
  onToggleObjectsPanel: () => void;
  onToggleEditor?: () => void;
  onToggleConsole: () => void;
  /** Kept for callers; the layout reset now lives in the page's File menu. */
  onResetLayout?: () => void;
  /** Kept for callers; upload now lives in the page's File menu. */
  onUpload?: () => void;
  /** Rendered before Compile (stimulus editor, File menu). */
  actionsSlot?: React.ReactNode;
  onCompile: () => void;
  onRun: () => void;
  onRestart: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomFit: () => void;
}

export const WaveformToolbar: React.FC<WaveformToolbarProps> = ({
  isCompiled,
  isCompiling,
  isPlaying = false,
  zoomLevel,
  currentTime,
  cursorB,
  timescale,
  projectPanelOpen,
  objectsPanelOpen,
  consoleOpen,
  mainView,
  onChangeMainView,
  onToggleProjectPanel,
  onToggleObjectsPanel,
  onToggleEditor,
  onToggleConsole,
  actionsSlot,
  onCompile,
  onRun,
  onRestart,
  onZoomIn,
  onZoomOut,
  onZoomFit,
}) => {
  const t = useT();
  return (
    <header
      className="h-[2.625rem] px-3 sm:px-4 flex items-center justify-between shrink-0 z-20 select-none border-b min-w-0"
      style={{
        backgroundColor: 'var(--bg-toolbar)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-primary)',
      }}
    >
      {/* ── Left: Panel View Toggles & Segmented View Switcher ─────── */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 min-w-0">
        <button
          data-testid="wf-toggle-project"
          onClick={onToggleProjectPanel}
          title={t("Toggle Project Panel (Alt+P)")}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-[0.25rem] text-xs font-medium border transition-colors ${
            projectPanelOpen
              ? 'bg-[var(--accent-subtle)] text-[var(--accent-primary)] border-[var(--accent-border)] font-semibold shadow-xs'
              : 'border-transparent text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]'
          }`}
        >
          <FolderOpen size={13} />
          <span className="hidden md:inline">{t("Project")}</span>
        </button>

        <button
          data-testid="wf-toggle-objects"
          onClick={onToggleObjectsPanel}
          title={t("Toggle Objects Panel (Alt+O)")}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-[0.25rem] text-xs font-medium border transition-colors ${
            objectsPanelOpen
              ? 'bg-[var(--accent-subtle)] text-[var(--accent-primary)] border-[var(--accent-border)] font-semibold shadow-xs'
              : 'border-transparent text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]'
          }`}
        >
          <Layers size={13} />
          <span className="hidden md:inline">{t("Objects")}</span>
        </button>

        <div className="w-px h-4 bg-[var(--border-subtle)] mx-0.5 hidden sm:block" />

        {/* ── Primary View Segmented Switcher ── */}
        <div
          className="flex items-center p-0.5 rounded-[0.25rem] border border-[var(--border-subtle)] bg-[var(--bg-input)] gap-0.5"
          role="tablist"
        >
          <button
            data-testid="wf-view-waveform"
            role="tab"
            aria-selected={mainView === 'waveform'}
            onClick={() => onChangeMainView('waveform')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-[0.1875rem] text-xs transition-colors ${
              mainView === 'waveform'
                ? 'bg-[var(--bg-panel)] text-[var(--text-primary)] border border-[var(--border-subtle)] font-semibold shadow-xs'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] border border-transparent'
            }`}
            title={t("Waveform View")}
          >
            <Activity size={13} />
            <span className="hidden sm:inline">{t("Waveform")}</span>
          </button>

          <button
            data-testid="wf-view-editor"
            data-legacy-toggle="wf-toggle-editor"
            role="tab"
            aria-selected={mainView === 'editor'}
            onClick={() => {
              onChangeMainView('editor');
              if (onToggleEditor) onToggleEditor();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-[0.1875rem] text-xs transition-colors ${
              mainView === 'editor'
                ? 'bg-[var(--bg-panel)] text-[var(--text-primary)] border border-[var(--border-subtle)] font-semibold shadow-xs'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] border border-transparent'
            }`}
            title={t("Code Editor View (Alt+E)")}
          >
            <FileCode size={13} />
            <span className="hidden sm:inline">{t("Editor")}</span>
          </button>

          <button
            data-testid="wf-view-split"
            role="tab"
            aria-selected={mainView === 'split'}
            onClick={() => onChangeMainView('split')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-[0.1875rem] text-xs transition-colors ${
              mainView === 'split'
                ? 'bg-[var(--bg-panel)] text-[var(--text-primary)] border border-[var(--border-subtle)] font-semibold shadow-xs'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)] border border-transparent'
            }`}
            title={t("Split View (Editor + Waveform)")}
          >
            <Columns size={13} />
            <span className="hidden lg:inline">{t("Split")}</span>
          </button>
        </div>

      </div>

      {/* ── Center: Engine Actions & Zoom ──────────────────────── */}
      <div className="flex items-center gap-1 sm:gap-2 shrink-0">
        {actionsSlot}

        <div className="w-px h-4 bg-[var(--border-subtle)] mx-0.5 hidden sm:block" />

        {/* Compile Button */}
        <button
          data-testid="wf-btn-compile"
          onClick={onCompile}
          disabled={isCompiling}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-[0.25rem] text-xs font-medium transition-colors shadow-xs ${
            isCompiling
              ? 'opacity-60 cursor-not-allowed bg-[var(--accent-primary)] text-white'
              : 'bg-[var(--accent-primary)] hover:bg-[var(--accent-hover)] text-white'
          }`}
          title={t("Compile HDL with Icarus Verilog")}
        >
          {isCompiling ? (
            <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Settings size={13} />
          )}
          <span>{isCompiling ? t("Compiling...") : t("Compile")}</span>
        </button>

        {/* Run Button (Preserves exact !isCompiled || isCompiling || isPlaying logic; neutral disabled styling without green glow) */}
        <button
          data-testid="wf-btn-run"
          onClick={onRun}
          disabled={!isCompiled || isCompiling || isPlaying}
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-[0.25rem] text-xs font-medium transition-colors shadow-xs ${
            !isCompiled || isCompiling || isPlaying
              ? 'bg-[var(--bg-surface)] text-[var(--text-disabled)] border border-[var(--border-subtle)] opacity-40 cursor-not-allowed'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
          title={t("Run Simulation Playback")}
        >
          <Play size={13} className={isPlaying ? 'opacity-80' : ''} />
          <span>{isPlaying ? t("Playing...") : t("Run")}</span>
        </button>

        {/* Restart Button */}
        {isCompiled && (
        <button
          data-testid="wf-btn-restart"
          onClick={onRestart}
          disabled={!isCompiled}
          className="hidden sm:flex p-1.5 rounded-[0.25rem] text-xs font-medium border transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          style={{
            backgroundColor: 'var(--bg-surface)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-primary)',
          }}
          title={t("Reset Playhead to Start")}
          aria-label={t("Reset Playhead to Start")}
        >
          <RotateCcw size={13} />
        </button>
        )}

        {/* Zoom and cursor readouts only matter once there is a waveform. */}
        {isCompiled && mainView !== 'editor' && (
        <>
        <div className="w-px h-4 bg-[var(--border-subtle)] mx-0.5 hidden md:block" />

        {/* Zoom Controls */}
        <div className="flex items-center rounded-[0.25rem] border border-[var(--border-subtle)] p-0.5 bg-[var(--bg-input)]">
          <button
            data-testid="wf-btn-zoom-out"
            onClick={onZoomOut}
            className="hidden md:flex p-1 hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)] rounded-[0.1875rem] text-[var(--text-muted)] transition-colors"
            title={t("Zoom Out")}
            aria-label={t("Zoom Out")}
          >
            <ZoomOut size={13} />
          </button>

          <span
            data-testid="wf-zoom-level"
            className="text-[0.6875rem] font-mono px-1.5 min-w-[2.75rem] text-center select-none text-[var(--text-secondary)] hidden lg:inline"
          >
            {(() => {
              if (zoomLevel >= 10) return `${zoomLevel.toFixed(0)}x`;
              if (zoomLevel >= 1) return `${zoomLevel.toFixed(1)}x`;
              if (zoomLevel >= 0.1) return `${zoomLevel.toFixed(2)}x`;
              if (zoomLevel >= 0.01) return `${zoomLevel.toFixed(3)}x`;
              return `${zoomLevel.toFixed(4)}x`;
            })()}
          </span>

          <button
            data-testid="wf-btn-zoom-in"
            onClick={onZoomIn}
            className="hidden md:flex p-1 hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)] rounded-[0.1875rem] text-[var(--text-muted)] transition-colors"
            title={t("Zoom In")}
            aria-label={t("Zoom In")}
          >
            <ZoomIn size={13} />
          </button>

          <button
            data-testid="wf-btn-zoom-fit"
            onClick={onZoomFit}
            className="flex items-center gap-1 px-1.5 py-0.5 ml-0 md:ml-0.5 hover:bg-[var(--bg-hover)] hover:text-[var(--accent-primary)] rounded-[0.1875rem] text-[var(--text-muted)] transition-colors text-[0.625rem] font-medium md:border-l md:border-[var(--border-subtle)]"
            title={t("Zoom to Fit Full Simulation Duration (Alt+F)")}
            aria-label={t("Zoom to Fit Full Simulation Duration (Alt+F)")}
          >
            <Maximize2 size={11} />
            <span className="hidden xl:inline">{t("Fit")}</span>
          </button>
        </div>
        </>
        )}
      </div>

      {/* ── Right: Real Timing Display & Console Toggle ─────────── */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Read-Only Cursors & Delta Timing Display */}
        {isCompiled && mainView !== 'editor' && (
        <>
        <div
          data-testid="wf-timing-display"
          className="hidden xl:flex items-center gap-2.5 px-2.5 py-1 border border-[var(--border-subtle)] rounded-[0.25rem] font-mono text-[0.6875rem] bg-[var(--bg-input)] text-[var(--text-secondary)] shadow-xs"
        >
          <div className="flex items-center gap-1">
            <span className="text-blue-400 font-semibold">A:</span>
            <span className="text-[var(--text-primary)] tabular-nums">
              {isCompiled && timescale ? formatTime(currentTime, timescale) : '—'}
            </span>
          </div>

          <span className="text-[var(--border-subtle)]">|</span>

          <div className="flex items-center gap-1">
            <span className="text-amber-400 font-semibold">B:</span>
            <span className={`tabular-nums ${isCompiled && cursorB !== null ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>
              {isCompiled && cursorB !== null ? formatTime(cursorB, timescale) : '—'}
            </span>
          </div>

          <span className="text-[var(--border-subtle)]">|</span>

          <div className="flex items-center gap-1">
            <span className="text-emerald-400 font-semibold">ΔT:</span>
            <span className={`tabular-nums ${isCompiled && cursorB !== null ? 'text-emerald-400 font-semibold' : 'text-[var(--text-muted)]'}`}>
              {isCompiled && cursorB !== null ? formatTime(Math.abs(cursorB - currentTime), timescale) : '—'}
            </span>
          </div>
        </div>

        <div className="w-px h-4 bg-[var(--border-subtle)] hidden xl:block" />
        </>
        )}

        {/* Console Toggle */}
        <button
          data-testid="wf-toggle-console"
          onClick={onToggleConsole}
          title={t("Toggle Console (Alt+T)")}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-[0.25rem] text-xs font-medium border transition-colors ${
            consoleOpen
              ? 'bg-[var(--accent-subtle)] text-[var(--accent-primary)] border-[var(--accent-border)] font-semibold shadow-xs'
              : 'border-transparent text-[var(--text-secondary)] hover:bg-[var(--bg-hover)] hover:text-[var(--text-primary)]'
          }`}
        >
          <Terminal size={13} />
          <span className="hidden sm:inline">{t("Console")}</span>
        </button>
      </div>
    </header>
  );
};
